<?php
// filepath: c:\xampp\htdocs\ChurchHub\search_members.php
require 'db.php';
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

$sql = "SELECT * FROM members WHERE 
  member_id LIKE :q OR
  first_name LIKE :q OR 
  middle_name LIKE :q OR 
  last_name LIKE :q OR 
  date_of_birth LIKE :q OR
  email LIKE :q OR 
  phone LIKE :q OR
  year_of_membership LIKE :q OR
  membership_status LIKE :q
  ORDER BY member_id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute(['q' => "%$q%"]);
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($members) === 0) {
  echo '<tr><td colspan="10" class="text-center">No members found.</td></tr>';
} else {
  foreach ($members as $m) {
    $status = strtolower($m['membership_status']);
    $badge  = 'secondary';
    if ($status === 'active')   $badge = 'success';
    if ($status === 'inactive') $badge = 'danger';
    echo '<tr style="font-size: 12px;">';
    echo '<td>' . htmlspecialchars($m['member_id']) . '</td>';
    echo '<td>' . htmlspecialchars($m['first_name']) . '</td>';
    echo '<td>' . htmlspecialchars($m['middle_name']) . '</td>';
    echo '<td>' . htmlspecialchars($m['last_name']) . '</td>';
    echo '<td>' . htmlspecialchars($m['date_of_birth']) . '</td>';
    echo '<td>' . htmlspecialchars($m['email']) . '</td>';
    echo '<td>' . htmlspecialchars($m['phone']) . '</td>';
    echo '<td>' . htmlspecialchars($m['year_of_membership']) . '</td>';
    echo '<td><span class="badge bg-' . $badge . '">' . htmlspecialchars($m['membership_status']) . '</span></td>';
    echo '<td>
      <button class="btn btn-info btn-sm view-info" data-id="' . htmlspecialchars($m['member_id']) . '">
        <i class="bi bi-eye"></i> View Info
      </button>
    </td>';
    echo '</tr>';
  }
}
?>