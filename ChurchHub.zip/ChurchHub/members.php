<?php
require 'db.php';
$settings = [
    'church_name' => 'ChurchHub',
    'church_address' => '123 Church Street, Cityville, Country',
    'contact_email' => 'example@church.com',
    'contact_phone' => '+1 234 567 890',
    'logo_path' => null
];
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings = array_merge($settings, $row);
}

$members = [];
$stmt = $pdo->query("SELECT * FROM members ORDER BY member_id DESC");
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ChurchHub - Members</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <script src="scripts/script.js"></script>
<link rel="stylesheet" href="view_members.php"><!-- jQuery and Bootstrap JS -->
  <style>
    body {
      background-color: #f4f6f9;
      margin: 0;
      font-family: Arial, sans-serif;
    }
    /* Fixed Sidebar */
    .sidebar {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: 250px;
      background: #343a40;
      color: #fff;
      overflow-y: auto;
      padding: 1rem 0;
    }
    .sidebar .brand {
      text-align: center;
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      font-weight: bold;
    }
    .sidebar .nav-link {
      color: #adb5bd;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s, color 0.3s;
    }
    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background: #495057;
      color: #fff;
    }
    .sidebar hr {
      border-color: rgba(255, 255, 255, 0.1);
    }
    /* Main Content */
    .main-content {
      margin-left: 250px;
      padding: 2rem;
      height: 100vh;
      overflow-y: auto;
    }
    .page-header {
      margin-bottom: 2rem;
    }
    .table thead {
      background-color: #007bff;
      color: #fff;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 200px;
      }
      .main-content {
        margin-left: 200px;
      }
    }

/* for statistics dropdown */
    .dropdown:hover .dropdown-menu {
  display: block;
}
  </style>
</head>
<body>
  <!-- Sidebar -->
<!-- Add IDs to the sidebar links -->
<nav class="sidebar">

<div class="brand text-center">
  <div id="sidebarLogoContainer" style="width: 50px; height: 50px; background-color: #007bff; border-radius: 50%; display: inline-block; margin-bottom: 0.5rem; overflow: hidden;">
    <?php if (!empty($settings['logo_path'])): ?>
      <img id="sidebarLogoImg" src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
    <?php else: ?>
      <span id="sidebarLogoText" style="color: #fff; font-size: 1.5rem; font-weight: bold; line-height: 50px; display: inline-block;">
        <?= strtoupper(substr($settings['church_name'], 0, 2)) ?>
      </span>
    <?php endif; ?>
  </div>
  <?= htmlspecialchars($settings['church_name']) ?>
</div>
<div class="address text-center mt-2" style="font-size: 1rem; font-weight: 500; color: #fff; background-color: #343a40; padding: 0.5rem; border-radius: 0.25rem;">
  <small><?= htmlspecialchars($settings['church_address']) ?></small>
</div>
<div class="contact-details text-center mt-2" style="font-size: 0.9rem; font-weight: 500; color: #fff; background-color: #495057; padding: 0.5rem; border-radius: 0.25rem;">
  <small>Email: <?= htmlspecialchars($settings['contact_email']) ?> | Phone: <?= htmlspecialchars($settings['contact_phone']) ?></small>
</div>

  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php" id="navDashboard">
        <i class="bi bi-house-door-fill me-2"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="members.php" id="navMembers">
        <i class="bi bi-people-fill me-2"></i> Members
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="events.php" id="navEvents">
        <i class="bi bi-calendar-event-fill me-2"></i> Events
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="communications.php" id="navCommunications">
        <i class="bi bi-chat-left-text-fill me-2"></i> Communications
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="donations.php" id="navDonations">
        <i class="bi bi-cash-stack me-2"></i> Church Funds
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="settings.php" id="navSettings">
        <i class="bi bi-gear-fill me-2"></i> Settings
      </a>
    </li>
  </ul>
  <hr>
  <div class="text-center">
    <small>v1.0.0</small>
  </div>
</nav>
  
  <!-- Main Content: Members Page -->
  <main class="main-content">
    <div class="container-fluid">
      <!-- Page Header -->
      <div class="page-header d-flex justify-content-between align-items-center">
        <h1>Members</h1>
        <!-- Scan Document Button -->
      <div class="d-flex gap-2">
        <button class="btn btn-success" id="scanDocumentBtn" type="button">
          <i class="bi bi-camera me-1"></i> Scan Document
        </button>
        <!-- Trigger the modal -->
          <button class="btn btn-primary"
            data-bs-toggle="modal"
            data-bs-target="#addMemberModal"
            type="button">
      <i class="bi bi-plus-lg me-1"></i> Add New Member
    </button>
</div>

        <!-- Hidden file input for scanning/uploading document -->
<input type="file" id="scanInput" accept="image/*,.pdf" style="display:none">

<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5.0.1/dist/tesseract.min.js"></script>
<script>
document.getElementById('scanDocumentBtn').addEventListener('click', function() {
  // Allow user to pick image/pdf/txt
  document.getElementById('scanInput').setAttribute('accept', 'image/*,.pdf,.txt');
  document.getElementById('scanInput').click();
});

document.getElementById('scanInput').addEventListener('change', function(event) {
  const file = event.target.files[0];
  if (!file) return;

  // Show the modal
  new bootstrap.Modal(document.getElementById('addMemberModal')).show();

  // If it's a text file, read and autofill directly
  if (file.type === "text/plain" || file.name.match(/\.txt$/i)) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const text = e.target.result;
      autofillFromText(text);
      alert('Text file loaded! Please review and complete the form.');
    };
    reader.readAsText(file);
    return;
  }

  // Otherwise, treat as image/pdf and use OCR
  alert('Scanning and extracting text from your document. Please wait...');
  const reader = new FileReader();
  reader.onload = function(e) {
    Tesseract.recognize(
      e.target.result,
      'eng',
      { logger: m => console.log(m) }
    ).then(({ data: { text } }) => {
      autofillFromText(text);
      alert('Scan complete! Please review and complete the form.');
    }).catch(err => {
      alert('Could not extract text from the scanned document.');
      console.error(err);
    });
  };
  reader.readAsDataURL(file);
});

// Helper function to autofill form fields from text
function autofillFromText(text) {
  // Map for single-value fields
  const map = {
    first_name: /First Name\s*:\s*(.+)/i,
    middle_name: /Middle Name\s*:\s*(.+)/i,
    last_name: /Last Name\s*:\s*(.+)/i,
    date_of_birth: /Date of Birth\s*:\s*([0-9\-\/]+)/i,
    place_of_birth: /Place of Birth\s*:\s*(.+)/i,
    citizenship: /Citizenship\s*:\s*(.+)/i,
    Gender: /Gender\s*:\s*(Male|Female)/i,
    'civil-status': /Civil Status\s*:\s*(.+)/i,
    email: /Email\s*:\s*([^\s]+)/i,
    phone: /Phone\s*:\s*([^\s]+)/i,
    'facebook-account': /Facebook Account\s*:\s*(.+)/i,
    'last-name-of-spouse': /Last Name of Spouse\s*:\s*(.+)/i,
    'first-name-of-spouse': /First Name of Spouse\s*:\s*(.+)/i,
    'middle-name-of-spouse': /Middle Name of Spouse\s*:\s*(.+)/i,
    spouse_date_of_birth: /Date of Birth \(Spouse\)|Spouse Date of Birth\s*:\s*([0-9\-\/]+)/i,
    date_of_marriage: /Date of Marriage\s*:\s*([0-9\-\/]+)/i,
    place_of_marriage: /Place of Marriage\s*:\s*(.+)/i,
    numChildren: /Number of Children\s*:\s*(\d+)/i,
    numEducation: /Number of Educational Attainments\s*:\s*(\d+)/i,
    numTrainings: /Number of Trainings With Certificates\s*:\s*(\d+)/i,
    'name-of-present-local-church': /Name of Present Local Church\s*:\s*(.+)/i,
    'year-of-membership': /Year of Membership\s*:\s*([0-9\-\/]+)/i,
    'ministry-position-involvement': /Ministry Position\/Involvement\s*:\s*(.+)/i,
    'year-of-conversion': /Year of Conversion\s*:\s*([0-9\-\/]+)/i,
    'year-of-water-baptism': /Year of Water Baptism\s*:\s*([0-9\-\/]+)/i,
    membership_status: /Status\s*:\s*(active|inactive)/i,
    'previous-religion': /Previous Religion\s*:\s*(.+)/i,
    'previous-christian-church-if-any': /Previous Christian Church\/ if any\s*:\s*(.+)/i,
    address: /Home City \/ Home Location|Address\s*:\s*(.+)/i
  };

  // Fill single-value fields
  Object.entries(map).forEach(([name, regex]) => {
    const match = text.match(regex);
    if (match && match[1]) {
      const el = document.querySelector(`[name="${name}"]`);
      if (el) el.value = match[1].trim();
    }
  });

  // Children
  const numChildrenMatch = text.match(/Number of Children\s*:\s*(\d+)/i);
  if (numChildrenMatch) {
    const num = parseInt(numChildrenMatch[1]);
    const numChildrenInput = document.getElementById('numChildren');
    if (numChildrenInput) {
      numChildrenInput.value = num;
      numChildrenInput.dispatchEvent(new Event('input'));
      setTimeout(() => {
        for (let i = 1; i <= num; i++) {
          const childMatch = text.match(new RegExp(`Name of Child ${i}\\s*:\\s*(.+)`, 'i'));
          if (childMatch && childMatch[1]) {
            const childInput = document.querySelector(`[name="child_name_${i}"]`);
            if (childInput) childInput.value = childMatch[1].trim();
          }
        }
      }, 100);
    }
  }

  // Education
  const numEduMatch = text.match(/Number of Educational Attainments\s*:\s*(\d+)/i);
  if (numEduMatch) {
    const num = parseInt(numEduMatch[1]);
    const numEduInput = document.getElementById('numEducation');
    if (numEduInput) {
      numEduInput.value = num;
      numEduInput.dispatchEvent(new Event('input'));
      setTimeout(() => {
        for (let i = 1; i <= num; i++) {
          const schoolMatch = text.match(new RegExp(`Name of School ${i}\\s*:\\s*(.+)`, 'i'));
          const yearMatch = text.match(new RegExp(`Year Graduated ${i}\\s*:\\s*(.+)`, 'i'));
          const courseMatch = text.match(new RegExp(`Course\\/Degree ${i}\\s*:\\s*(.+)`, 'i'));
          if (schoolMatch && schoolMatch[1]) {
            const schoolInput = document.querySelector(`[name="school_name_${i}"]`);
            if (schoolInput) schoolInput.value = schoolMatch[1].trim();
          }
          if (yearMatch && yearMatch[1]) {
            const yearInput = document.querySelector(`[name="year_graduated_${i}"]`);
            if (yearInput) yearInput.value = yearMatch[1].trim();
          }
          if (courseMatch && courseMatch[1]) {
            const courseInput = document.querySelector(`[name="course_degree_${i}"]`);
            if (courseInput) courseInput.value = courseMatch[1].trim();
          }
        }
      }, 100);
    }
  }

  // Trainings
  const numTrainMatch = text.match(/Number of Trainings With Certificates\s*:\s*(\d+)/i);
  if (numTrainMatch) {
    const num = parseInt(numTrainMatch[1]);
    const numTrainInput = document.getElementById('numTrainings');
    if (numTrainInput) {
      numTrainInput.value = num;
      numTrainInput.dispatchEvent(new Event('input'));
      setTimeout(() => {
        for (let i = 1; i <= num; i++) {
          const tnameMatch = text.match(new RegExp(`Name of Training ${i}\\s*:\\s*(.+)`, 'i'));
          const tyearMatch = text.match(new RegExp(`Year Taken\\/Completed ${i}\\s*:\\s*(.+)`, 'i'));
          const ttitleMatch = text.match(new RegExp(`Title\\/Designation ${i}\\s*:\\s*(.+)`, 'i'));
          if (tnameMatch && tnameMatch[1]) {
            const tnameInput = document.querySelector(`[name="training_name_${i}"]`);
            if (tnameInput) tnameInput.value = tnameMatch[1].trim();
          }
          if (tyearMatch && tyearMatch[1]) {
            const tyearInput = document.querySelector(`[name="year_taken_${i}"]`);
            if (tyearInput) tyearInput.value = tyearMatch[1].trim();
          }
          if (ttitleMatch && ttitleMatch[1]) {
            const ttitleInput = document.querySelector(`[name="title_designation_${i}"]`);
            if (ttitleInput) ttitleInput.value = ttitleMatch[1].trim();
          }
        }
      }, 100);
    }
  }

  // Spiritual Gifts (checkboxes)
  [
    "Shepherding", "Organizing", "Teaching", "Word of Wisdom & Knowledge", "Preaching",
    "Prophecy", "Healing", "Leadership", "Counseling", "Speaking in Tongues"
  ].forEach(gift => {
    if (text.match(new RegExp(gift, 'i'))) {
      const cb = document.querySelector(`input[name="spiritual_gifts[]"][value="${gift}"]`);
      if (cb) cb.checked = true;
    }
  });

  // Skills (checkboxes)
  [
    "Driving", "Writing", "Sewing", "Selling/Marketing", "Doing Electrical Jobs",
    "Doing Computer Work", "Cooking", "Making Handicrafts", "Doing Agricultural Work"
  ].forEach(skill => {
    if (text.match(new RegExp(skill, 'i'))) {
      const cb = document.querySelector(`input[name="skills[]"][value="${skill}"]`);
      if (cb) cb.checked = true;
    }
  });

  // Sports/Hobbies (checkboxes)
  [
    "Basketball", "Badminton", "Golf", "Bowling", "Volleyball", "Gym/Work-out",
    "Swimming", "Lawn Tennis", "Table Tennis"
  ].forEach(hobby => {
    if (text.match(new RegExp(hobby, 'i'))) {
      const cb = document.querySelector(`input[name="sports_hobbies[]"][value="${hobby}"]`);
      if (cb) cb.checked = true;
    }
  });

  // Health Profile (checkboxes)
  [
    "Using Eyeglasses", "Using Contact Lenses", "With Denture", "Diabetes",
    "High Blood Pressure", "Dysmenorrhea", "Migraine", "Heart Disease"
  ].forEach(cond => {
    if (text.match(new RegExp(cond, 'i'))) {
      const cb = document.querySelector(`input[name="health_profile[]"][value="${cond}"]`);
      if (cb) cb.checked = true;
    }
  });

  // Others fields (Skills, Hobbies, Health)
  const otherSkillMatch = text.match(/Other Skills\s*:\s*(.+)/i);
  if (otherSkillMatch && otherSkillMatch[1]) {
    document.getElementById('skillOthers').checked = true;
    document.getElementById('otherSkillField').style.display = 'block';
    document.querySelector('#otherSkillField input').value = otherSkillMatch[1].trim();
  }
  const otherHobbyMatch = text.match(/Other Hobbies\s*:\s*(.+)/i);
  if (otherHobbyMatch && otherHobbyMatch[1]) {
    document.getElementById('hobbyOthers').checked = true;
    document.getElementById('otherHobbyField').style.display = 'block';
    document.querySelector('#otherHobbyField input').value = otherHobbyMatch[1].trim();
  }
  const otherHealthMatch = text.match(/Other Health Conditions\s*:\s*(.+)/i);
  if (otherHealthMatch && otherHealthMatch[1]) {
    document.getElementById('healthOthers').checked = true;
    document.getElementById('otherHealthField').style.display = 'block';
    document.querySelector('#otherHealthField input').value = otherHealthMatch[1].trim();
  }
}
</script>
      </div>

      <!-- Statistics Modal -->
<div class="modal fade" id="statsModal" tabindex="-1" aria-labelledby="statsModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="statsModalLabel">Member Statistics</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="statsModalBody">
        <!-- Stats will be loaded here -->
      </div>
    </div>
  </div>
</div>

<div class="dropdown ms-3">
  <button class="btn btn-outline-primary dropdown-toggle" type="button" id="statsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
    <i class="bi bi-bar-chart"></i> Members Added Statistics
  </button>
  <ul class="dropdown-menu" aria-labelledby="statsDropdown">
    <li><a class="dropdown-item" href="#" id="showStatsYear">Per Year</a></li>
    <li><a class="dropdown-item" href="#" id="showStatsMonth">Per Month</a></li>
  </ul>
</div>

<!-- Add gap below statistics dropdown -->
<div class="mb-1"></div>

<!-- Search Bar -->
<div class="mb-4">
  <input type="search" class="form-control" id="memberSearch" placeholder="Search members...">
</div>

      <!-- Members Table -->
      <div class="card">
        <div class="card-body p-0">
          <div class="table-responsive">
          <?php include 'view_members.php'; ?>
            <!-- filepath: c:\xampp\htdocs\ChurchHub\view_members.php -->
<table class="table table-striped mb-0">
  <thead>
    <tr style="font-size: 12px;">
      <th>Member ID</th>
      <th>First Name</th>
      <th>Middle Name</th>
      <th>Last Name</th>
      <th>Date of Birth</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Year of Membership</th>
      <th>Status</th>
      <th style="width: 150px;">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php if (count($members) === 0): ?>
      <!-- Sample Data Rows -->
      <tr>
        <td>1</td>
        <td>John</td>
        <td>M</td>
        <td>Doe</td>
        <td>1980-01-15</td>
        <td>john.doe@example.com</td>
        <td>+1-234-567-890</td>
        <td>2020-06-10</td>
        <td><span class="badge bg-success">active</span></td>
        <td><button class="btn btn-info btn-sm"><i class="bi bi-eye"></i> View Info</button></td>
      </tr>
      <tr>
        <td>2</td>
        <td>Jane</td>
        <td>A</td>
        <td>Smith</td>
        <td>1985-04-20</td>
        <td>jane.smith@example.com</td>
        <td>+1-987-654-321</td>
        <td>2019-03-05</td>
        <td><span class="badge bg-danger">inactive</span></td>
        <td><button class="btn btn-info btn-sm"><i class="bi bi-eye"></i> View Info</button></td>
      </tr>
     <?php else: ?>
       <?php foreach ($members as $m): ?> 
        <?php
          $status = strtolower($m['membership_status']);
          $badge  = 'secondary';
          if ($status === 'active')   $badge = 'success';
          if ($status === 'inactive') $badge = 'danger';
        ?>
        <tr style="font-size: 12px;">
          <td><?= htmlspecialchars($m['member_id']) ?></td>
          <td><?= htmlspecialchars($m['first_name']) ?></td>
          <td><?= htmlspecialchars($m['middle_name']) ?></td>
          <td><?= htmlspecialchars($m['last_name']) ?></td>
          <td><?= htmlspecialchars($m['date_of_birth']) ?></td>
          <td><?= htmlspecialchars($m['email']) ?></td>
          <td><?= htmlspecialchars($m['phone']) ?></td>
          <td><?= htmlspecialchars($m['year_of_membership']) ?></td>
          <td><span class="badge bg-<?= $badge ?>"><?= htmlspecialchars($m['membership_status']) ?></span></td>
          <td>
            <button
              class="btn btn-info btn-sm view-info"
              data-id="<?= htmlspecialchars($m['member_id']) ?>">
              <i class="bi bi-eye"></i> View Info
            </button>
          </td>

        </tr>
      <?php endforeach; ?>
    <?php endif; ?>
  </tbody>
</table>
          </div>

          <!-- Modal -->
<div class="modal fade" id="memberInfoModal" tabindex="-1" aria-labelledby="memberInfoLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="memberInfoLabel">Member Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <dl class="row">
          <?php foreach ($fields as $key=>$label): ?>
            <dt class="col-sm-4"><?= $label ?></dt>
            <dd class="col-sm-8" data-field="<?= $key ?>">–</dd>
          <?php endforeach; ?>
        </dl>
        <!-- Print Button -->
        <div class="mb-3 text-end">
          <button class="btn btn-outline-secondary" id="printMemberPaper">
            <i class="bi bi-printer"></i> Print
          </button>
        </div>
      </div>
      <div class="modal-body">
  <dl class="row">
    <dt class="col-sm-4">Spiritual Gifts</dt>
    <dd class="col-sm-8" id="modalSpiritualGifts">–</dd>

    <dt class="col-sm-4">Skills</dt>
    <dd class="col-sm-8" id="modalSkills">–</dd>

    <dt class="col-sm-4">Sports/Hobbies</dt>
    <dd class="col-sm-8" id="modalHobbies">–</dd>

    <dt class="col-sm-4">Health Profile</dt>
    <dd class="col-sm-8" id="modalHealthProfile">–</dd>
  </dl>
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- SCRIPTS (at end of body!) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Remove ALL duplicate handlers for button.view-info and use only this one!
$(function () {
  $('body').on('click', 'button.view-info', function (e) {
    e.preventDefault();
    const id = $(this).data('id');
    console.log('▶️ fetching member', id);

    // Clear all fields
    $('#memberInfoModal [data-field]').text('…');
    $('#modalSpiritualGifts').text('Loading...');
    $('#modalSkills').text('Loading...');
    $('#modalHobbies').text('Loading...');
    $('#modalHealthProfile').text('Loading...');

    // Fetch main info
    $.getJSON('get_member.php', { id })
      .done(function (data) {
        $.each(data, function (k, v) {
          $('#memberInfoModal [data-field="' + k + '"]').text(v || '');
        });
        // Fetch extra details (gifts, skills, etc)
        $.getJSON('get_member_details.php', { member_id: id }, function (details) {
          $('#modalSpiritualGifts').text(details.gifts && details.gifts.length ? details.gifts.join(', ') : 'None');
          $('#modalSkills').text(details.skills && details.skills.length ? details.skills.join(', ') : 'None');
          $('#modalHobbies').text(details.hobbies && details.hobbies.length ? details.hobbies.join(', ') : 'None');
          $('#modalHealthProfile').text(details.health && details.health.length ? details.health.join(', ') : 'None');
        }).fail(function () {
          $('#modalSpiritualGifts, #modalSkills, #modalHobbies, #modalHealthProfile').text('None');
        });

        // Only show the modal ONCE
        var modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('memberInfoModal'));
        modal.show();
      })
      .fail(function (xhr) {
        alert('Could not load member: ' + xhr.responseText);
      });
  });

  // Remove leftover backdrop and modal-open class when modal is hidden
  $('#memberInfoModal').on('hidden.bs.modal', function () {
    $('body').removeClass('modal-open');
    $('.modal-backdrop').remove();
  });
});
</script>
<script>
// Statistics dropdown handlers     
</script>
<!-- Close the modal and remove backdrop when hidden -->
<script>
$('#memberInfoModal').on('hidden.bs.modal', function () {
  $('body').removeClass('modal-open'); // Remove the class that keeps the backdrop
  $('.modal-backdrop').remove(); // Remove any remaining backdrop
});
</script>
        </div>
      </div><!-- /.card -->
    </div><!-- /.container-fluid -->

  <!-- Add Member Modal -->
<div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="post" action="submit_members.php">
        <div class="modal-header">
          <h5 class="modal-title" id="addMemberLabel">Add New Member</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3">
            <!-- First Name -->
            <div class="col-md-6">
              <label class="form-label">First Name</label>
              <input type="text" name="first_name" class="form-control" required>
            </div>
            <!-- Middle Name -->
            <div class="col-md-6">
              <label class="form-label">Middle Name</label>
              <input type="text" name="middle_name" class="form-control">
            </div>
            <!-- Last Name -->
            <div class="col-md-6">
              <label class="form-label">Last Name</label>
              <input type="text" name="last_name" class="form-control" required>
            </div>
            <!-- Date of Birth -->
            <div class="col-md-6">
              <label class="form-label">Date of Birth</label>
              <input type="date" name="date_of_birth" class="form-control" required>
            </div>
            <!-- Place of Birth -->
            <div class="col-md-6">
              <label class="form-label">Place of Birth</label>
              <input type="text" name="place_of_birth" class="form-control" required>
            </div>
            <!-- Citizenship -->
            <div class="col-md-6">
              <label class="form-label">Citizenship</label>
              <input type="text" name="citizenship" class="form-control" required>
            </div>
            <!-- Gender -->
            <div class="col-md-6">
              <label class="form-label">Gender</label>
              <select name="Gender" class="form-select">
                <option value="Male" selected>Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <!-- Civil Status -->
            <div class="col-md-6">
              <label class="form-label">Civil Status</label>
              <select name="civil-status" class="form-select">
                <option value="Single" selected>Single</option>
                <option value="Married">Married</option>
                <option value="Separated">Separated</option>
                <option value="Widowed">Widowed</option>
              </select>
            </div>
            <!-- Email -->
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <!-- Phone -->
            <div class="col-md-6">
              <label class="form-label">Phone</label>
              <input type="text" name="phone" class="form-control" required>
            </div>
            <!-- Facebook Account -->
            <div class="col-md-6">
              <label class="form-label">Facebook Account</label>
              <input type="text" name="facebook-account" class="form-control" required>
            </div>
            <label class="form-label" style="font-weight: bold; text-align: center;">If Married...</label>
            <span></span>
            <!-- Last Name of Spouse -->
            <div class="col-md-6">
              <label class="form-label">Last Name of Spouse</label>
              <input type="text" name="last-name-of-spouse" class="form-control">
            </div>
            <!-- First Name of Spouse -->
            <div class="col-md-6">
              <label class="form-label">First Name of Spouse</label>
              <input type="text" name="first-name-of-spouse" class="form-control">
            </div>
            <!-- Middle Name of Spouse -->
            <div class="col-md-6">
              <label class="form-label">Middle Name of Spouse</label>
              <input type="text" name="middle-name-of-spouse" class="form-control">
            </div>
            <!-- Date of Birth -->
            <div class="col-md-6">
              <label class="form-label">Date of Birth</label>
              <input type="date" name="spouse_date_of_birth" class="form-control">
            </div>
            <!-- Date of Marriage -->
            <div class="col-md-6">
              <label class="form-label">Date of Marriage</label>
              <input type="date" name="date_of_marriage" class="form-control">
            </div>
            <!-- Place of Marriage -->
            <div class="col-md-6">
              <label class="form-label">Place of Marriage</label>
              <input type="text" name="place_of_marriage" class="form-control" required>
            </div>
            <label class="form-label" style="font-weight: bold; text-align: center;">Children Living...</label>
                        <!-- Name of Child/ren -->
                        <div class="col-md-6">
                          <label class="form-label">Number of Children</label>
                          <input type="number" id="numChildren" class="form-control mb-3" placeholder="Enter number of children" min="1" max="10">

                          <div id="childrenFields"></div>

                          <script>
                            document.getElementById('numChildren').addEventListener('input', function () {
                            const numChildren = parseInt(this.value, 10);
                            const childrenFieldsContainer = document.getElementById('childrenFields');
                            childrenFieldsContainer.innerHTML = ''; // Clear existing fields

                            if (numChildren > 0 && numChildren <= 10) {
                              for (let i = 1; i <= numChildren; i++) {
                              const childField = document.createElement('div');
                              childField.classList.add('mb-3');
                              childField.innerHTML = `
                              <label class="form-label">Name of Child ${i}</label>
                              <input type="text" name="child_name_${i}" class="form-control" placeholder="Enter name of child ${i}" required>
                              `;
                              childrenFieldsContainer.appendChild(childField);
                              }
                            }
                            });
                            </script>
                          </div>

                          <!-- Educational Attainment -->
                          <div class="col-md-6">
                            <label class="form-label">Number of Educational Attainments</label>
                            <input type="number" id="numEducation" class="form-control mb-3" placeholder="Enter number of educational attainments" min="1" max="5">

                            <div id="educationFields"></div>

                            <script>
                            document.getElementById('numEducation').addEventListener('input', function () {
                            const numEducation = parseInt(this.value, 10);
                            const educationFieldsContainer = document.getElementById('educationFields');
                            educationFieldsContainer.innerHTML = ''; // Clear existing fields

                            if (numEducation > 0 && numEducation <= 5) {
                              for (let i = 1; i <= numEducation; i++) {
                              const educationField = document.createElement('div');
                              educationField.classList.add('mb-3');
                              educationField.innerHTML = `
                              <label class="form-label">Name of School ${i}</label>
                              <input type="text" name="school_name_${i}" class="form-control mb-2" placeholder="Enter name of school ${i}" required>
                              <label class="form-label">Year Graduated ${i}</label>
                              <input type="text" name="year_graduated_${i}" class="form-control mb-2" placeholder="Enter year graduated ${i}" required>
                              <label class="form-label">Course/Degree ${i}</label>
                              <input type="text" name="course_degree_${i}" class="form-control" placeholder="Enter course/degree ${i}" required>
                              `;
                              educationFieldsContainer.appendChild(educationField);
                              }
                            }
                            });
                            </script>
                          </div>

                          <!-- Training With Certificates -->
                          <div class="col-md-6">
                            <label class="form-label">Number of Trainings With Certificates</label>
                            <input type="number" id="numTrainings" class="form-control mb-3" placeholder="Enter number of trainings" min="1" max="5">

                            <div id="trainingFields"></div>

                            <script>
                            document.getElementById('numTrainings').addEventListener('input', function () {
                            const numTrainings = parseInt(this.value, 10);
                            const trainingFieldsContainer = document.getElementById('trainingFields');
                            trainingFieldsContainer.innerHTML = ''; // Clear existing fields

                            if (numTrainings > 0 && numTrainings <= 5) {
                              for (let i = 1; i <= numTrainings; i++) {
                              const trainingField = document.createElement('div');
                              trainingField.classList.add('mb-3');
                              trainingField.innerHTML = `
                              <label class="form-label">Name of Training ${i}</label>
                              <input type="text" name="training_name_${i}" class="form-control mb-2" placeholder="Enter name of training ${i}" required>
                              <label class="form-label">Year Taken/Completed ${i}</label>
                              <input type="text" name="year_taken_${i}" class="form-control mb-2" placeholder="Enter year taken/completed ${i}" required>
                              <label class="form-label">Title/Designation ${i}</label>
                              <input type="text" name="title_designation_${i}" class="form-control" placeholder="Enter title/designation ${i}" required>
                              `;
                              trainingFieldsContainer.appendChild(trainingField);
                              }
                            }
                            });
                            </script>
                          </div>
                                      <!-- Name of Present Local Church -->
            <div class="col-md-6">
              <label class="form-label">Name of Present Local Church</label>
              <input type="text" name="name-of-present-local-church" class="form-control">
            </div>
            <!-- Year of Membership -->
            <div class="col-md-6">
              <label class="form-label">Year of Membership</label>
              <input type="date" name="year-of-membership" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <!-- Ministry Position/Involvement -->
            <div class="col-md-6">
              <label class="form-label">Ministry Position/Involvement</label>
              <input type="text" name="ministry-position-involvement" class="form-control">
            </div>
            <!-- Year of Conversion-->
            <div class="col-md-6">
              <label class="form-label">Year of Conversion</label>
              <input type="date" name="year-of-conversion" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <!-- Year of Water Baptism-->
            <div class="col-md-6">
              <label class="form-label">Year of Water Baptism</label>
              <input type="date" name="year-of-water-baptism" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>
            <!-- Status -->
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="membership_status" class="form-select">
                <option value="active" selected>Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>

            <!-- Previous Religion -->
            <div class="col-md-6">
              <label class="form-label">Previous Religion</label>
              <input type="text" name="previous-religion" class="form-control">
            </div>
            <!-- Previous Christian Church/ if any -->
            <div class="col-md-6">
              <label class="form-label">Previous Christian Church/ if any</label>
              <input type="text" name="previous-christian-church-if-any" class="form-control">
            </div>
            <div class="row">
              <!-- Spiritual Gifts Column -->
              <div class="col-md-6">
                <label class="form-label" style="font-weight: bold; text-align: center;">Spiritual Gifts</label>
                <div class="col-md-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Shepherding" id="giftShepherding">
                    <label class="form-check-label" for="giftShepherding">Shepherding</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Organizing" id="giftOrganizing">
                    <label class="form-check-label" for="giftOrganizing">Organizing</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Teaching" id="giftTeaching">
                    <label class="form-check-label" for="giftTeaching">Teaching</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Word of Wisdom & Knowledge" id="giftWisdomKnowledge">
                    <label class="form-check-label" for="giftWisdomKnowledge">Word of Wisdom & Knowledge</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Preaching" id="giftPreaching">
                    <label class="form-check-label" for="giftPreaching">Preaching</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Prophecy" id="giftProphecy">
                    <label class="form-check-label" for="giftProphecy">Prophecy</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Healing" id="giftHealing">
                    <label class="form-check-label" for="giftHealing">Healing</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Leadership" id="giftLeadership">
                    <label class="form-check-label" for="giftLeadership">Leadership</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Counseling" id="giftCounseling">
                    <label class="form-check-label" for="giftCounseling">Counseling</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="spiritual_gifts[]" value="Speaking in Tongues" id="giftSpeakingTongues">
                    <label class="form-check-label" for="giftSpeakingTongues">Speaking in Tongues</label>
                  </div>
                </div>
              </div>
            
              <!-- Skills Column -->
              <div class="col-md-6">
                <label class="form-label" style="font-weight: bold; text-align: center;">Skills</label>
                <div class="col-md-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Driving" id="skillDriving">
                    <label class="form-check-label" for="skillDriving">Driving</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Writing" id="skillWriting">
                    <label class="form-check-label" for="skillWriting">Writing</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Sewing" id="skillSewing">
                    <label class="form-check-label" for="skillSewing">Sewing</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Selling/Marketing" id="skillSellingMarketing">
                    <label class="form-check-label" for="skillSellingMarketing">Selling/Marketing</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Doing Electrical Jobs" id="skillElectricalJobs">
                    <label class="form-check-label" for="skillElectricalJobs">Doing Electrical Jobs</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Doing Computer Work" id="skillComputerWork">
                    <label class="form-check-label" for="skillComputerWork">Doing Computer Work</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Cooking" id="skillCooking">
                    <label class="form-check-label" for="skillCooking">Cooking</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Making Handicrafts" id="skillHandicrafts">
                    <label class="form-check-label" for="skillHandicrafts">Making Handicrafts</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="skills[]" value="Doing Agricultural Work" id="skillAgriculturalWork">
                    <label class="form-check-label" for="skillAgriculturalWork">Doing Agricultural Work</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="skillOthers">
                    <label class="form-check-label" for="skillOthers">Others</label>
                  </div>
                  <div id="otherSkillField" style="display: none;" class="mt-2">
                    <input type="text" name="skills[]" class="form-control" placeholder="Please specify other skills">
                  </div>
                </div>
              </div>
            </div>
            
            <script>
              document.getElementById('skillOthers').addEventListener('change', function () {
                const otherSkillField = document.getElementById('otherSkillField');
                if (this.checked) {
                  otherSkillField.style.display = 'block';
                } else {
                  otherSkillField.style.display = 'none';
                }
              });
            </script>
            <div class="row">
              <!-- Sports, Hobbies/Recreation Column -->
              <div class="col-md-6">
                <label class="form-label" style="font-weight: bold; text-align: center;">Sports, Hobbies/Recreation</label>
                <div class="col-md-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Basketball" id="hobbyBasketball">
                    <label class="form-check-label" for="hobbyBasketball">Basketball</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Badminton" id="hobbyBadminton">
                    <label class="form-check-label" for="hobbyBadminton">Badminton</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Golf" id="hobbyGolf">
                    <label class="form-check-label" for="hobbyGolf">Golf</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Bowling" id="hobbyBowling">
                    <label class="form-check-label" for="hobbyBowling">Bowling</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Volleyball" id="hobbyVolleyball">
                    <label class="form-check-label" for="hobbyVolleyball">Volleyball</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Gym/Work-out" id="hobbyGymWorkout">
                    <label class="form-check-label" for="hobbyGymWorkout">Gym/Work-out</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Swimming" id="hobbySwimming">
                    <label class="form-check-label" for="hobbySwimming">Swimming</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Lawn Tennis" id="hobbyLawnTennis">
                    <label class="form-check-label" for="hobbyLawnTennis">Lawn Tennis</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="sports_hobbies[]" value="Table Tennis" id="hobbyTableTennis">
                    <label class="form-check-label" for="hobbyTableTennis">Table Tennis</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="hobbyOthers">
                    <label class="form-check-label" for="hobbyOthers">Others</label>
                  </div>
                  <div id="otherHobbyField" style="display: none;" class="mt-2">
                    <input type="text" name="sports_hobbies[]" class="form-control" placeholder="Please specify other hobbies">
                  </div>
                </div>
              </div>
            
              <!-- Health Profile Column -->
              <div class="col-md-6">
                <label class="form-label" style="font-weight: bold; text-align: center;">Health Profile</label>
                <div class="col-md-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="Using Eyeglasses" id="healthEyeglasses">
                    <label class="form-check-label" for="healthEyeglasses">Using Eyeglasses</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="Using Contact Lenses" id="healthContactLenses">
                    <label class="form-check-label" for="healthContactLenses">Using Contact Lenses</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="With Denture" id="healthDenture">
                    <label class="form-check-label" for="healthDenture">With Denture</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="Diabetes" id="healthDiabetes">
                    <label class="form-check-label" for="healthDiabetes">Diabetes</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="High Blood Pressure" id="healthHighBloodPressure">
                    <label class="form-check-label" for="healthHighBloodPressure">High Blood Pressure</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="Dysmenorrhea" id="healthDysmenorrhea">
                    <label class="form-check-label" for="healthDysmenorrhea">Dysmenorrhea</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="Migraine" id="healthMigraine">
                    <label class="form-check-label" for="healthMigraine">Migraine</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="health_profile[]" value="Heart Disease" id="healthHeartDisease">
                    <label class="form-check-label" for="healthHeartDisease">Heart Disease</label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="healthOthers">
                    <label class="form-check-label" for="healthOthers">Others</label>
                  </div>
                  <div id="otherHealthField" style="display: none;" class="mt-2">
                    <input type="text" name="health_profile[]" class="form-control" placeholder="Please specify other health conditions">
                  </div>
                </div>
              </div>
            </div>
            
            <script>
              document.getElementById('hobbyOthers').addEventListener('change', function () {
                const otherHobbyField = document.getElementById('otherHobbyField');
                otherHobbyField.style.display = this.checked ? 'block' : 'none';
              });
            
              document.getElementById('healthOthers').addEventListener('change', function () {
                const otherHealthField = document.getElementById('otherHealthField');
                otherHealthField.style.display = this.checked ? 'block' : 'none';
              });
            </script>
            
            <!-- Home Address -->
            <div class="col-md-12">
              <label class="form-label">Home City / Home Location</label>
              <input type="text" name="address" class="form-control">
            </div>

          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Add Member</button>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>
</div>


         <script>
$('#memberSearch').on('input', function() {
  const q = $(this).val();
  $.get('search_members.php', { q }, function(html) {
    $('.table tbody').html(html);
  });
});
</script>
  
 <!-- HTML and Bootstrap for the Members Page -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(function() {
  $('#showStatsYear').on('click', function(e) {
    e.preventDefault();
    $('#statsModalLabel').text('Members Added Per Year');
    $('#statsModalBody').html('Loading...');
    $('#statsModal').modal('show');
    $.get('stats_year.php', function(html) {
      $('#statsModalBody').html(html);
    });
  });

  $('#showStatsMonth').on('click', function(e) {
    e.preventDefault();
    $('#statsModalLabel').text('Members Added Per Month');
    $('#statsModalBody').html('Loading...');
    $('#statsModal').modal('show');
    $.get('stats_month.php', function(html) {
      $('#statsModalBody').html(html);
    });
  });
});
</script>


  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(function() {
  $('#printMemberPaper').on('click', function() {
    printMemberDetails();
  });

  function printMemberDetails() {
    // Get logo HTML (from PHP variable)
    var logoHtml = '';
    <?php if (!empty($settings['logo_path'])): ?>
      logoHtml = '<div style="text-align:center;margin-bottom:1rem;"><img src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="height:70px;border-radius:12px;box-shadow:0 2px 8px #0002;"></div>';
    <?php else: ?>
      logoHtml = '<div style="text-align:center;margin-bottom:1rem;"><span style="font-size:2.5rem;font-weight:bold;color:#007bff;"><?= strtoupper(substr($settings['church_name'], 0, 2)) ?></span></div>';
    <?php endif; ?>

    // Clone the modal content for printing
    var printContents = $('#memberInfoModal .modal-content').clone();
    printContents.find('.modal-footer').remove();
    printContents.find('#printMemberPaper').remove();

    // Extract main details and extra details
    var mainDetails = printContents.find('dl.row').first().prop('outerHTML');
    var extraDetails = printContents.find('dl.row').last().prop('outerHTML');

    // Build a clean print layout
    var html = `
      <div style="max-width:700px;margin:0 auto;padding:2rem 1rem;">
        ${logoHtml}
        <h2 style="text-align:center;margin-bottom:0.5rem;"><?= htmlspecialchars($settings['church_name']) ?></h2>
        <div style="text-align:center;color:#888;margin-bottom:1.5rem;font-size:1rem;">
          <?= htmlspecialchars($settings['church_address']) ?>
        </div>
        <hr style="margin:1.5rem 0;">
        <h4 style="margin-bottom:1rem;">Member Details</h4>
        ${mainDetails}
        <hr style="margin:2rem 0 1rem;">
        <h5 style="margin-bottom:1rem;">Other Information</h5>
        ${extraDetails}
      </div>
      <style>
        dl.row {margin-bottom:0;}
        dt {font-weight:600;}
        dd {margin-bottom:0.5rem;}
        @media print {
          body {background: #fff;}
          .modal-content, .btn, .modal-footer {display:none!important;}
        }
      </style>
    `;

    // Create a new window for printing
    var printWindow = window.open('', '', 'height=700,width=900');
    printWindow.document.write('<html><head><title>Member Details</title>');
    printWindow.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">');
    printWindow.document.write('</head><body>');
    printWindow.document.write(html);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    setTimeout(function() {
      printWindow.print();
      printWindow.close();
    }, 500);
  }
});
</script>
</body>
</html>
