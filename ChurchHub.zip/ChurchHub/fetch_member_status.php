<?php
// filepath: c:\xampp\htdocs\ChurchHub\fetch_member_status.php
require 'db.php';

$status = $_GET['status'] ?? 'all';
$sort   = $_GET['sort'] ?? 'asc';

$sql = "SELECT member_id, first_name, last_name, membership_status FROM members";
$params = [];

if ($status === 'active' || $status === 'inactive') {
    $sql .= " WHERE membership_status = :status";
    $params['status'] = $status;
}

$sql .= " ORDER BY last_name " . ($sort === 'desc' ? 'DESC' : 'ASC') . ", first_name " . ($sort === 'desc' ? 'DESC' : 'ASC') ;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$members = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($members as $i => $m) {
    $badge = $m['membership_status'] === 'active' ? 'success' : 'danger';
    echo '<tr>';
    echo '<td>' . ($i + 1) . '</td>';
    echo '<td>' . htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) . '</td>';
    echo '<td><span class="badge bg-' . $badge . '">' . htmlspecialchars($m['membership_status']) . '</span></td>';
    echo '</tr>';
}
if (empty($members)) {
    echo '<tr><td colspan="3" class="text-center text-muted">No members found.</td></tr>';
}
?>