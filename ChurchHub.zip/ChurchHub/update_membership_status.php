<?php
require 'db.php';

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$data = json_decode(file_get_contents('php://input'), true);
$memberId = $data['member_id'] ?? null;
$status = $data['status'] ?? '';

if (!$memberId || !$status) {
    echo json_encode(['success' => false, 'error' => 'Missing member ID or status']);
    exit;
}

try {
    // Check if the member exists
    $stmt = $pdo->prepare("SELECT member_id FROM members WHERE member_id = :member_id");
    $stmt->execute(['member_id' => $memberId]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Member not found.']);
        exit;
    }

    // Update the membership status
    $stmt = $pdo->prepare("UPDATE members SET membership_status = :status WHERE member_id = :member_id");
    $stmt->execute(['status' => $status, 'member_id' => $memberId]);

    if ($stmt->rowCount()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Member not found or already ' . $status]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>