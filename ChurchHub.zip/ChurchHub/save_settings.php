<?php
// save_settings.php
require 'db.php';

$churchName = $_POST['churchName'] ?? '';
$churchAddress = $_POST['churchAddress'] ?? '';
$contactEmail = $_POST['contactEmail'] ?? '';
$contactPhone = $_POST['contactPhone'] ?? '';
$logoBlob = null;

if (isset($_FILES['churchLogo']) && $_FILES['churchLogo']['error'] === UPLOAD_ERR_OK) {
    $logoBlob = file_get_contents($_FILES['churchLogo']['tmp_name']);
}

// If no new logo, keep the old one
if ($logoBlob === null) {
    $stmt = $pdo->query("SELECT logo_path FROM settings WHERE id = 1 LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $logoBlob = $row['logo_path'] ?? null;
}

$sql = "INSERT INTO settings (id, church_name, church_address, contact_email, contact_phone, logo_path)
        VALUES (1, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        church_name = VALUES(church_name),
        church_address = VALUES(church_address),
        contact_email = VALUES(contact_email),
        contact_phone = VALUES(contact_phone),
        logo_path = VALUES(logo_path)";
$stmt = $pdo->prepare($sql);
$success = $stmt->execute([$churchName, $churchAddress, $contactEmail, $contactPhone, $logoBlob]);

echo json_encode(['success' => $success]);