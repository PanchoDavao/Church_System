<?php
require 'db.php';

$query = $_GET['query'] ?? '';

if ($query) {
    $stmt = $pdo->prepare("
        SELECT member_id, first_name, middle_name, last_name
        FROM members
        WHERE CONCAT(first_name, ' ', middle_name, ' ', last_name) LIKE :query
        ORDER BY last_name, first_name
        LIMIT 10
    ");
    $stmt->execute(['query' => "%$query%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($results);
}
?>