<?php
// filepath: c:\xampp\htdocs\ChurchHub\stats_year.php
require 'db.php';
$stmt = $pdo->query("SELECT YEAR(join_date) as year, COUNT(*) as total FROM members GROUP BY YEAR(join_date) ORDER BY year DESC");
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$data) {
    echo "<p>No data found.</p>";
} else {
    echo "<ul class='list-group'>";
    foreach ($data as $row) {
        echo "<li class='list-group-item d-flex justify-content-between align-items-center'>";
        echo htmlspecialchars($row['year']);
        echo "<span class='badge bg-primary rounded-pill'>" . htmlspecialchars($row['total']) . "</span>";
        echo "</li>";
    }
    echo "</ul>";
}
?>