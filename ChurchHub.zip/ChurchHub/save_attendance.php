<?php
// save_attendance.php
// Handles saving a new attendance record to the database

require 'db.php';

// Ensure we're handling a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}

// Validate and sanitize input
$event_id      = isset($_POST['event_id'])      ? (int) $_POST['event_id'] : null;
$member_id     = isset($_POST['member_id'])     ? (int) $_POST['member_id'] : null;
$check_in_time = isset($_POST['check_in_time']) ? trim($_POST['check_in_time']) : null;

$errors = [];

if (empty($event_id)) {
    $errors[] = 'Event is required.';
}
if (empty($member_id)) {
    $errors[] = 'Member is required.';
}
if (empty($check_in_time)) {
    $errors[] = 'Check-in time is required.';
}

if (!empty($errors)) {
    // If errors exist, optionally pass them back via session or query string
    // For simplicity, redirect back with a generic error flag
    header('Location: dashboard.php?attendance_error=1');
    exit;
}

try {
    // Prepare and execute the INSERT statement
    $stmt = $pdo->prepare(
        'INSERT INTO attendance (event_id, member_id, check_in_time)
         VALUES (:event_id, :member_id, :check_in_time)'
    );
    $stmt->execute([
        ':event_id'      => $event_id,
        ':member_id'     => $member_id,
        ':check_in_time' => $check_in_time,
    ]);

    // Redirect back to dashboard with a success flag
    header('Location: dashboard.php?attendance_saved=1');
    exit;

} catch (PDOException $e) {
    // Log or handle exception as needed
    error_log('Attendance insert error: ' . $e->getMessage());
    header('Location: dashboard.php?attendance_error=1');
    exit;
}
?>
