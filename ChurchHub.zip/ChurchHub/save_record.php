<?php
require 'db.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Retrieve form data
        $recordType = $_POST['record_type'] ?? null;
        $name = $_POST['name'] ?? null;
        $date = $_POST['date'] ?? null;
        $location = $_POST['location'] ?? null;
        $pastor = $_POST['pastor'] ?? null;
        $remarks = $_POST['remarks'] ?? null;
        $memberId = $_POST['member_id'] ?? null; // Get member_id from the form

        // Validate required fields
        if (!$recordType || !$name || !$date || !$location) {
            throw new Exception('Required fields are missing.');
        }

        // If member_id is not provided, look it up based on the name
        if (!$memberId) {
            $nameParts = explode(' ', $name);
            $firstName = $nameParts[0];
            $lastName = $nameParts[count($nameParts) - 1];
            $middleName = count($nameParts) > 2 ? implode(' ', array_slice($nameParts, 1, -1)) : '';

            $stmt = $pdo->prepare("
                SELECT member_id 
                FROM members 
                WHERE first_name = :first_name 
                  AND (middle_name = :middle_name OR middle_name IS NULL OR middle_name = '') 
                  AND last_name = :last_name
            ");
            $stmt->execute([
                'first_name' => $firstName,
                'middle_name' => $middleName,
                'last_name' => $lastName,
            ]);
            $member = $stmt->fetch(PDO::FETCH_ASSOC);

            $memberId = $member['member_id'] ?? null;
        }

        // Prepare SQL query to insert the record
        $stmt = $pdo->prepare("
            INSERT INTO records (record_type, name, date, location, officiating_pastor, remarks, member_id)
            VALUES (:record_type, :name, :date, :location, :pastor, :remarks, :member_id)
        ");

        // Bind parameters
        $stmt->bindParam(':record_type', $recordType);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':pastor', $pastor);
        $stmt->bindParam(':remarks', $remarks);
        $stmt->bindParam(':member_id', $memberId);

        // Execute the query
        $stmt->execute();

        // Redirect with success message
        header('Location: dashboard.php?success=Record saved successfully');
        exit;
    } catch (Exception $e) {
        // Handle errors
        header('Location: dashboard.php?error=' . urlencode($e->getMessage()));
        exit;
    }
}
?>