<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'churchhub';
$user = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Get member_id from request
$member_id = $_GET['member_id'] ?? null;
if (!$member_id) {
    echo json_encode(['error' => 'Invalid member ID']);
    exit;
}

// Fetch data from related tables
try {
    // Fetch spiritual gifts
    $stmt = $pdo->prepare("SELECT gift FROM member_gifts WHERE member_id = ?");
    $stmt->execute([$member_id]);
    $gifts = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Fetch skills
    $stmt = $pdo->prepare("SELECT skill FROM member_skills WHERE member_id = ?");
    $stmt->execute([$member_id]);
    $skills = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Fetch hobbies
    $stmt = $pdo->prepare("SELECT hobby FROM member_hobbies WHERE member_id = ?");
    $stmt->execute([$member_id]);
    $hobbies = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Fetch health profile
    $stmt = $pdo->prepare("SELECT condition_name FROM member_health WHERE member_id = ?");
    $stmt->execute([$member_id]);
    $health = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Return data as JSON
    echo json_encode([
        'gifts' => $gifts,
        'skills' => $skills,
        'hobbies' => $hobbies,
        'health' => $health,
    ]);
} catch (Exception $e) {
    echo json_encode(['error' => 'Failed to fetch data']);
}