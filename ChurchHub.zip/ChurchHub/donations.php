<?php
require 'db.php';
$settings = [
    'church_name' => 'ChurchHub',
    'church_address' => '123 Church Street, Cityville, Country',
    'contact_email' => 'example@church.com',
    'contact_phone' => '+1 234 567 890',
    'logo_path' => null
];
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings = array_merge($settings, $row);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ChurchHub Donations</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <script src="scripts/script.js"></script>
  <style>
    body {
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }
    /* Fixed Sidebar */
    .sidebar {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: 250px;
      background: #343a40;
      color: #fff;
      overflow-y: auto;
      padding: 1rem 0;
    }
    .sidebar .brand {
      text-align: center;
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      font-weight: bold;
    }
    .sidebar .nav-link {
      color: #adb5bd;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s, color 0.3s;
    }
    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background: #495057;
      color: #fff;
    }
    .sidebar hr {
      border-color: rgba(255, 255, 255, 0.1);
    }
    /* Main Content */
    .main-content {
      margin-left: 250px;
      padding: 2rem;
      overflow-y: auto;
      height: 100vh;
    }
    .card {
      border: none;
      border-radius: 0.5rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .card-header {
      background-color: #007bff;
      color: #fff;
      border-top-left-radius: 0.5rem;
      border-top-right-radius: 0.5rem;
      font-size: 1.1rem;
      font-weight: bold;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 200px;
      }
      .main-content {
        margin-left: 200px;
      }
    }
    /* Accordion customization for donations */
    .accordion-button {
      background-color: #f8f9fa;
      color: #333;
    }
    .accordion-button:not(.collapsed) {
      background-color: #e2e6ea;
      color: #333;
    }
    .accordion-body a {
      text-decoration: none;
      color: #007bff;
      display: block;
      padding: 0.25rem 0;
    }
    .accordion-body a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
<!-- Add IDs to the sidebar links -->
<nav class="sidebar">
  
<div class="brand text-center">
  <div id="sidebarLogoContainer" style="width: 50px; height: 50px; background-color: #007bff; border-radius: 50%; display: inline-block; margin-bottom: 0.5rem; overflow: hidden;">
    <?php if (!empty($settings['logo_path'])): ?>
      <img id="sidebarLogoImg" src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
    <?php else: ?>
      <span id="sidebarLogoText" style="color: #fff; font-size: 1.5rem; font-weight: bold; line-height: 50px; display: inline-block;">
        <?= strtoupper(substr($settings['church_name'], 0, 2)) ?>
      </span>
    <?php endif; ?>
  </div>
  <?= htmlspecialchars($settings['church_name']) ?>
</div>
<div class="address text-center mt-2" style="font-size: 1rem; font-weight: 500; color: #fff; background-color: #343a40; padding: 0.5rem; border-radius: 0.25rem;">
  <small><?= htmlspecialchars($settings['church_address']) ?></small>
</div>
<div class="contact-details text-center mt-2" style="font-size: 0.9rem; font-weight: 500; color: #fff; background-color: #495057; padding: 0.5rem; border-radius: 0.25rem;">
  <small>Email: <?= htmlspecialchars($settings['contact_email']) ?> | Phone: <?= htmlspecialchars($settings['contact_phone']) ?></small>
</div>

  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php" id="navDashboard">
        <i class="bi bi-house-door-fill me-2"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="members.php" id="navMembers">
        <i class="bi bi-people-fill me-2"></i> Members
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="events.php" id="navEvents">
        <i class="bi bi-calendar-event-fill me-2"></i> Events
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="communications.php" id="navCommunications">
        <i class="bi bi-chat-left-text-fill me-2"></i> Communications
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="donations.php" id="navDonations">
        <i class="bi bi-cash-stack me-2"></i> Church Funds
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="settings.php" id="navSettings">
        <i class="bi bi-gear-fill me-2"></i> Settings
      </a>
    </li>
  </ul>
  <hr>
  <div class="text-center">
    <small>v1.0.0</small>
  </div>
</nav>
  
  <!-- Main Content -->
  <main class="main-content">
    <div class="container-fluid">
      <h1 class="mb-4">Tithes and Offering</h1>
      <p class="text-muted">
        Manage donation records. The system supports features based on the donations table fields:
        Donation ID, Member ID, Donation Date, Amount, and Donation Type.
      </p>
      <!-- Donation Features Accordion -->
      <div class="accordion" id="donationFeaturesAccordion">
        <!-- View All Donations -->
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
              <i class="bi bi-list-ul me-2"></i> View All Donations
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#donationFeaturesAccordion">
            <div class="accordion-body">
              <a href="donations-list.html">List donations (donation_id, member_id, donation_date, amount, donation_type)</a>
            </div>
          </div>
        </div>
<!-- Add a New Donation -->
<div class="accordion-item">
  <h2 class="accordion-header" id="headingTwo">
    <button class="accordion-button collapsed" type="button"
            data-bs-toggle="collapse" data-bs-target="#collapseTwo"
            aria-expanded="false" aria-controls="collapseTwo">
      <i class="bi bi-plus-circle me-2"></i> Add New Donation
    </button>
  </h2>
  <div id="collapseTwo" class="accordion-collapse collapse"
       aria-labelledby="headingTwo"
       data-bs-parent="#donationFeaturesAccordion">
    <div class="accordion-body">
      <form id="donationFormInline">
        <div class="row g-3">
          <div class="col-md-3">
            <label for="memberIdInline" class="form-label">Member ID</label>
            <input type="number" class="form-control" id="memberIdInline" required>
          </div>
          <div class="col-md-3">
            <label for="donationDateInline" class="form-label">Date</label>
            <input type="date" class="form-control" id="donationDateInline" required>
          </div>
          <div class="col-md-3">
            <label for="amountInline" class="form-label">Amount ($)</label>
            <input type="number" step="0.01" class="form-control" id="amountInline" required>
          </div>
          <div class="col-md-3">
            <label for="donationTypeInline" class="form-label">Type</label>
            <select class="form-select" id="donationTypeInline" required>
              <option value="">Choose...</option>
              <option value="Tithe">Tithe</option>
              <option value="Offering">Offering</option>
              <option value="Building Fund">Building Fund</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>
        <div class="mt-3">
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-save me-1"></i> Save Donation
          </button>
          <div id="alertInline" class="mt-2"></div>
        </div>
      </form>
    </div>
  </div>
</div>

        <!-- Donation Reports -->
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingThree">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
              <i class="bi bi-bar-chart-line me-2"></i> Donation Reports
            </button>
          </h2>
          <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#donationFeaturesAccordion">
            <div class="accordion-body">
              <a href="donation-report-date.html">Report by Date</a>
              <a href="donation-report-member.html">Report by Member</a>
              <a href="donation-report-type.html">Report by Donation Type</a>
            </div>
          </div>
        </div>
      </div>
      <!-- End of Donation Features Accordion -->
    </div>
  </main>
  
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById('donationFormInline').addEventListener('submit', function(e) {
      e.preventDefault();
  
      const donation = {
        member_id: parseInt(document.getElementById('memberIdInline').value, 10),
        donation_date: document.getElementById('donationDateInline').value,
        amount: parseFloat(document.getElementById('amountInline').value),
        donation_type: document.getElementById('donationTypeInline').value
      };
  
      // Demo: save to localStorage
      let list = JSON.parse(localStorage.getItem('donations') || '[]');
      donation.donation_id = list.length ? list[list.length - 1].donation_id + 1 : 1;
      list.push(donation);
      localStorage.setItem('donations', JSON.stringify(list));
  
      // Show feedback
      const alertEl = document.getElementById('alertInline');
      alertEl.innerHTML = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          Donation saved!
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
  
      this.reset();
    });
  </script>
  
</body>
</html>
