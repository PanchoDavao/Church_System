<?php
// filepath: c:\xampp\htdocs\ChurchHub\save_member_department.php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $memberName = $_POST['member_name'];
  $departmentName = $_POST['department_name'];

  $stmt = $pdo->prepare("
    INSERT INTO member_departments (member_name, department_name) 
    VALUES (:member_name, :department_name)
  ");
  $stmt->execute([
    ':member_name' => $memberName,
    ':department_name' => $departmentName,
  ]);

  header('Location: dashboard.php?success=Member department added successfully');
  exit;
}
?>