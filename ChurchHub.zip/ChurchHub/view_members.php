<?php
// members.php

// 1. Database connection
$host     = 'localhost';
$dbname   = 'churchhub';
$user     = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// 2. Fetch members
$sql = "
    SELECT 
        member_id,
        first_name,
        middle_name,
        last_name,
        date_of_birth,
        email,
        phone,
        year_of_membership,
        membership_status
    FROM members
    ORDER BY member_id DESC
";
$stmt = $pdo->query($sql);
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
// … after $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
$fields = [
    'member_id'           => 'Member ID',
    'first_name'          => 'First Name',
    'middle_name'         => 'Middle Name',
    'last_name'           => 'Last Name',
    'date_of_birth'       => 'Date of Birth',
    'place_of_birth'      => 'Place of Birth',
    'citizenship'         => 'Citizenship',
    'gender'              => 'Gender',
    'civil_status'        => 'Civil Status',
    'email'               => 'Email',
    'phone'               => 'Phone',
    'facebook_account'    => 'Facebook',
    'spouse_last'         => 'Spouse Last',
    'spouse_first'        => 'Spouse First',
    'spouse_middle'       => 'Spouse Middle',
    'spouse_dob'          => 'Spouse DOB',
    'date_of_marriage'    => 'Date of Marriage',
    'place_of_marriage'   => 'Place of Marriage',
    'year_of_membership'  => 'Year of Membership',
    'ministry_position'   => 'Ministry Position',
    'year_of_conversion'  => 'Year of Conversion',
    'year_of_baptism'     => 'Year of Baptism',
    'previous_religion'   => 'Previous Religion',
    'previous_church'     => 'Previous Church',
    'address'             => 'Address',
    'membership_status'   => 'Membership Status',
  ];
  
?>
