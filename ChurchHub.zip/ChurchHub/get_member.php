<?php
// filepath: c:\xampp\htdocs\ChurchHub\get_member.php
header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'No member ID provided']);
    exit;
}

$memberId = intval($_GET['id']);

// Database connection
$pdo = new PDO("mysql:host=localhost;dbname=churchhub;charset=utf8mb4", 'root', '');
$sql = "SELECT * FROM members WHERE member_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$memberId]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if ($member) {
    echo json_encode($member);
} else {
    echo json_encode(['error' => 'Member not found']);
}