<?php
session_start();
require_once 'db.php';  // make sure this sets up $pdo

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: events.php?error=invalid_method');
    exit;
}

// sanitize inputs
$name        = trim($_POST['event_title']       ?? '');
$date        = trim($_POST['event_date_time']        ?? '');
$location    = trim($_POST['event_location']    ?? '');
$description = trim($_POST['event_description'] ?? '');

// validate
$errors = [];
if ($name === '')        $errors[] = 'Event name is required.';
if ($date === '')        $errors[] = 'Event date is required.';
if ($location === '')    $errors[] = 'Location is required.';
if ($description === '') $errors[] = 'Description is required.';

if ($errors) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['old'] = $_POST;
    header('Location: events.php');
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO events
          (event_name, event_date, location, description)
        VALUES
          (:name, :date, :loc, :desc)
    ");
    $stmt->execute([
        ':name' => $name,
        ':date' => $date,
        ':loc'  => $location,
        ':desc' => $description,
    ]);

    $_SESSION['success'] = 'Event “'.htmlspecialchars($name).'” has been saved.';
    header('Location: events.php');
    exit;

} catch (PDOException $e) {
    error_log('Save Event Error: '.$e->getMessage());
    $_SESSION['error'] = 'Could not save event. Please try again later.';
    header('Location: events.php');
    exit;
}
