<?php

// require 'auth.php';
// if (isset($_GET['logout'])) {
//     logout();
// }
// $loginError = '';
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
//     $username = $_POST['username'] ?? '';
//     $password = $_POST['password'] ?? '';
//     if (!validateUser($username, $password)) {
//         $loginError = 'Invalid username or password.';
//     }
// }

// dashboard.php
// Include the PDO-based database connection
require 'db.php';
$settings = [
    'church_name' => 'ChurchHub',
    'church_address' => '123 Church Street, Cityville, Country',
    'contact_email' => 'example@church.com',
    'contact_phone' => '+1 234 567 890',
    'logo_path' => null
];
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings = array_merge($settings, $row);
}
// dashboard.php (somewhere above your HTML `<head>`)
$attStmt = $pdo->query("
  SELECT attendance_id, event_id, member_id, check_in_time
  FROM attendance
  ORDER BY check_in_time DESC
  LIMIT 1
");
$attendances = $attStmt->fetchAll();

// turn on exceptions so you’ll see if your query fails
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// pull events
$eventsStmt = $pdo->query("
  SELECT event_id, event_name
  FROM events
  ORDER BY event_date DESC
");
$events = $eventsStmt->fetchAll(PDO::FETCH_ASSOC);

// pull members
$membersStmt = $pdo->query("
  SELECT member_id, first_name, last_name
  FROM members
  ORDER BY last_name, first_name
");
$members = $membersStmt->fetchAll(PDO::FETCH_ASSOC);


$membersStmt = $pdo->query("
  SELECT member_id, first_name, middle_name, last_name
  FROM members
  ORDER BY last_name, first_name
");
$members = $membersStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all events, ordered by date
$sql    = "SELECT * FROM `events` ORDER BY `event_date` DESC";
$result = $pdo->query($sql);
?>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($_GET['success']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (isset($_GET['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($_GET['error']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
      <?php
// Get total members
$totalMembers = $pdo->query("SELECT COUNT(*) FROM members")->fetchColumn();

// Get members with attendance this month
$activeMembers = $pdo->query("
  SELECT COUNT(DISTINCT member_id) 
  FROM attendance 
  WHERE MONTH(check_in_time) = MONTH(CURRENT_DATE()) 
    AND YEAR(check_in_time) = YEAR(CURRENT_DATE())
")->fetchColumn();

// Calculate percentage
$percentage = $totalMembers > 0 ? round(($activeMembers / $totalMembers) * 100, 1) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ChurchHub System Home</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <script src="scripts/script.js"></script>

<link rel="stylesheet" href="style/dashboard.css">
    <style>
      /* your existing styles… */
      .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background-color: #007bff;
        color: #fff;
        border-top-left-radius: 0.5rem;
        border-top-right-radius: 0.5rem;
        font-size: 1.1rem;
        font-weight: bold;
      }
      .btn-add-member {
        color: #fff;
        border: none;
        background: transparent;
        font-size: 1.2rem;
      }
      .btn-add-member:hover {
        color: #e0e0e0;
      }
    </style>
</head>
<body>

<!-- if (!isLoggedIn()): ?>
  <div id="loginOverlay" style="position:fixed;z-index:9999;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);">
    <div class="modal show d-block" tabindex="-1" style="background:rgba(0,0,0,0.2);height:100vh;">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <form method="post" autocomplete="off">
            <div class="modal-header">
              <h5 class="modal-title">Login Required</h5>
            </div>
            <div class="modal-body">
              <?php if ($loginError): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div>
              <?php endif; ?>
              <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" name="username" id="username" required autofocus>
              </div>
              <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" required>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script>
    // Prevent interaction with the page behind the modal
    document.body.style.overflow = 'hidden';
  </script> -->
  <!-- Sidebar -->
<!-- Add IDs to the sidebar links -->
<!-- filepath: c:\xampp\htdocs\ChurchHub\dashboard.php -->
<nav class="sidebar">

<div class="brand text-center">
  <div id="sidebarLogoContainer" style="width: 50px; height: 50px; background-color: #007bff; border-radius: 50%; display: inline-block; margin-bottom: 0.5rem; overflow: hidden;">
    <?php if (!empty($settings['logo_path'])): ?>
      <img id="sidebarLogoImg" src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
    <?php else: ?>
      <span id="sidebarLogoText" style="color: #fff; font-size: 1.5rem; font-weight: bold; line-height: 50px; display: inline-block;">
        <?= strtoupper(substr($settings['church_name'], 0, 2)) ?>
      </span>
    <?php endif; ?>
  </div>
  <?= htmlspecialchars($settings['church_name']) ?>
</div>
<div class="address text-center mt-2" style="font-size: 1rem; font-weight: 500; color: #fff; background-color: #343a40; padding: 0.5rem; border-radius: 0.25rem;">
  <small><?= htmlspecialchars($settings['church_address']) ?></small>
</div>
<div class="contact-details text-center mt-2" style="font-size: 0.9rem; font-weight: 500; color: #fff; background-color: #495057; padding: 0.5rem; border-radius: 0.25rem;">
  <small>Email: <?= htmlspecialchars($settings['contact_email']) ?> | Phone: <?= htmlspecialchars($settings['contact_phone']) ?></small>
</div>
  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php" id="navDashboard">
        <i class="bi bi-house-door-fill me-2"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="members.php" id="navMembers">
        <i class="bi bi-people-fill me-2"></i> Members
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="events.php" id="navEvents">
        <i class="bi bi-calendar-event-fill me-2"></i> Events
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="communications.php" id="navCommunications">
        <i class="bi bi-chat-left-text-fill me-2"></i> Communications
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="donations.php" id="navDonations">
        <i class="bi bi-cash-stack me-2"></i> Church Funds
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="settings.php" id="navSettings">
        <i class="bi bi-gear-fill me-2"></i> Settings
      </a>
    </li>
    <!-- a href="dashboard.php?logout=1" class="btn btn-danger btn-sm mt-3">Logout</a> -->
  </ul>
  <hr>
  <div class="text-center">
    <small>v1.0.0</small>
  </div>
</nav>
  
  <!-- Main Content -->
  <main class="main-content">
    <div class="container-fluid">
      <h1 class="dashboard-title">System Home</h1>
      <p class="text-muted">Overview of modules based on the ChurchHub database schema.</p>
      <div class="row g-4">
<!-- Addresses Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Addresses
      <button type="button" class="btn-add-member" id="btnAddAddress" title="Add New Address">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Manage street, city, state, postal code, and country details.</p>
    </div>
  </div>
</div>
<!-- Attendance Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Attendance
      <!-- Add new attendance -->
      <button
        type="button"
        class="btn-add-member"
        id="btnAddAttendance"
        data-bs-toggle="modal"
        data-bs-target="#attendanceModal"
        title="Add Attendance"
      >
        <i class="bi bi-plus-circle-fill"></i>
      </button>
      <!-- View all attendance -->
      <button
        type="button"
        class="btn-add-member ms-2"
        id="btnViewAttendance"
        data-bs-toggle="modal"
        data-bs-target="#attendanceListModal"
        title="View All Attendance"
      >
        <i class="bi bi-list-ul"></i>
      </button>
    </div>
    <div class="card-body p-2">
      <table class="table table-sm mb-0">
        <thead>
          <tr>
            <th>#</th>
            <th>E‑ID</th>
            <th>M‑ID</th>
            <th>Check‑in</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($attendances)): ?>
            <?php foreach ($attendances as $a): ?>
              <tr>
                <td><?= $a['attendance_id'] ?></td>
                <td><?= htmlspecialchars($a['event_id']) ?></td>
                <td><?= htmlspecialchars($a['member_id']) ?></td>
                <td><?= date('Y‑m‑d H:i', strtotime($a['check_in_time'])) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="4" class="text-center text-muted">No records</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Full Attendance Listing Modal -->
<div
  class="modal fade"
  id="attendanceListModal"
  tabindex="-1"
  aria-labelledby="attendanceListLabel"
  aria-hidden="true"
>
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="attendanceListLabel">All Attendance Records</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <table class="table table-bordered table-hover">
          <thead class="table-light">
            <tr>
              <th>Attendance no.</th>
              <th>Event Name</th>
              <th>Member's Name</th>
              <th>Check-in Time</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $allStmt = $pdo->query("
              SELECT
                a.attendance_id,
                e.event_name,
                CONCAT(m.first_name, ' ', m.last_name) AS member_full_name,
                a.check_in_time
              FROM attendance AS a
              INNER JOIN events   AS e ON a.event_id  = e.event_id
              INNER JOIN members  AS m ON a.member_id = m.member_id
              ORDER BY a.check_in_time DESC
            ");
            while ($row = $allStmt->fetch()) {
              echo '<tr>'
                . '<td>' . $row['attendance_id'] . '</td>'
                . '<td>' . htmlspecialchars($row['event_name']) . '</td>'
                . '<td>' . htmlspecialchars($row['member_full_name']) . '</td>'
                . '<td>' . htmlspecialchars($row['check_in_time']) . '</td>'
                . '</tr>';
            }
            ?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Record Attendance Modal -->
<div
  class="modal fade"
  id="attendanceModal"           <!-- must match data-bs-target -->
  tabindex="-1"
  aria-labelledby="attendanceModalLabel"
  aria-hidden="true"
>
  <div class="modal-dialog">
    <form action="save_attendance.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="attendanceModalLabel">Record Attendance</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="event_id" class="form-label">Event</label>
          <select name="event_id" id="event_id" class="form-select" required>
            <option value="" disabled selected>-- Select Event --</option>
            <?php foreach ($events as $e): ?>
              <option value="<?= $e['event_id'] ?>">
                <?= htmlspecialchars($e['event_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="member_id" class="form-label">Member</label>
          <select name="member_id" id="member_id" class="form-select" required>
            <option value="" disabled selected>-- Select Member --</option>
            <?php foreach ($members as $m): ?>
              <option value="<?= $m['member_id'] ?>">
                (<?= $m['member_id'] ?>) <?= htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="check_in_time" class="form-label">Check‑in Time</label>
          <input
            type="datetime-local"
            class="form-control"
            name="check_in_time"
            id="check_in_time"
            required
          >
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
          Cancel
        </button>
        <button type="submit" class="btn btn-primary">Save Attendance</button>
      </div>
    </form>
  </div>
</div>


<!-- Communications Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Communications
      <button type="button" class="btn-add-member" id="btnAddCommunication" title="Add New Communication">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Send and manage messages to members.</p>
    </div>
  </div>
</div>
<!-- Donations Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Donations
      <button type="button" class="btn-add-member" id="btnAddDonation" title="Add New Donation">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Record and track donation amounts and types.</p>
    </div>
  </div>
</div>
<!-- Member Status Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Member Status
      <button type="button" class="btn-add-member" id="btnAddMemberStatus" title="Add New Member Status">
        <i class="bi bi-plus-circle-fill"></i>
      </button>

      <button type="button" class="btn btn-sm btn-primary ms-2" id="btnViewMemberStatus" data-bs-toggle="modal" data-bs-target="#memberStatusModal" title="View Monthly Status">
        <i class="bi bi-list"></i> View
      </button>
    </div>
    <div class="card-body">
      <p class="card-text mb-1">
        <strong>Active this month:</strong> <?= $activeMembers ?> / <?= $totalMembers ?> (<?= $percentage ?>%)
      </p>
    </div>
  </div>
</div>
<!-- Member Status Modal -->
<div class="modal fade" id="memberStatusModal" tabindex="-1" aria-labelledby="memberStatusModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="memberStatusModalLabel">Member Status List</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row mb-3">
          <div class="col-md-6">
            <select id="statusFilter" class="form-select">
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          <div class="col-md-6">
            <select id="sortFilter" class="form-select">
              <option value="asc">Sort by Name (A-Z)</option>
              <option value="desc">Sort by Name (Z-A)</option>
            </select>
          </div>
        </div>
        <div class="table-responsive">
          <table class="table table-bordered" id="memberStatusTable">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <!-- Data will be loaded here -->
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  function loadMemberStatus() {
    const status = document.getElementById('statusFilter').value;
    const sort = document.getElementById('sortFilter').value;
    fetch(`fetch_member_status.php?status=${status}&sort=${sort}`)
      .then(response => response.text())
      .then(html => {
        document.querySelector('#memberStatusTable tbody').innerHTML = html;
      });
  }

  // Load data when modal is shown
  const memberStatusModal = document.getElementById('memberStatusModal');
  memberStatusModal.addEventListener('show.bs.modal', loadMemberStatus);

  // Reload on filter change
  document.getElementById('statusFilter').addEventListener('change', loadMemberStatus);
  document.getElementById('sortFilter').addEventListener('change', loadMemberStatus);
});
</script>

<!-- Member Events Modal -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
  <span>Events</span>
  <button type="button"
          class="btn btn-sm btn-success"
          id="btnAddEvent"
          title="Add New Event"
          data-bs-toggle="modal"
          data-bs-target="#eventModal">
    <i class="bi bi-plus-circle-fill"></i>
  </button>
</div>
<div class="card-body">
  <?php if ($result && $result->rowCount() > 0): ?>
    <ul class="list-group">
      <?php while ($row = $result->fetch(PDO::FETCH_ASSOC)): ?>
        <li class="list-group-item">
          <h6 class="mb-1"><?= htmlspecialchars($row['event_name']) ?></h6>
          <small class="text-muted">
            <?= date('F j, Y \\a\\t g:ia', strtotime($row['event_date'])) ?>
          </small>
          <p class="mt-2 mb-0"><?= htmlspecialchars($row['description']) ?></p>
        </li>
      <?php endwhile; ?>
    </ul>
  <?php else: ?>
    <p class="text-muted mb-0">No events scheduled.</p>
  <?php endif; ?>
</div>
  </div>
</div>

<!-- Add / Edit Event Modal -->
<div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="save_event.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="eventModalLabel">Add New Event</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="event-id" value="">
        <div class="mb-3">
          <label for="event-name" class="form-label">Event Name</label>
          <input type="text" class="form-control" id="event-name" name="event_name" required>
        </div>
        <div class="mb-3">
          <label for="event-date" class="form-label">Date & Time</label>
          <input type="datetime-local" class="form-control" id="event-date" name="event_date" required>
        </div>
        <div class="mb-3">
          <label for="event-category" class="form-label">Category</label>
          <input type="text" class="form-control" id="event-category" name="category">
        </div>
        <div class="mb-3">
          <label for="event-desc" class="form-label">Description</label>
          <textarea class="form-control" id="event-desc" name="description" rows="3"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Event</button>
      </div>
    </form>
  </div>
</div>

<script>
// Optional: if you want this modal to handle “Edit” later, you can fill fields dynamically.
// For now, “Add” is enough, thanks to the hidden #event-id being empty.
document.getElementById('btnAddEvent').addEventListener('click', () => {
  document.getElementById('eventModalLabel').textContent = 'Add New Event';
  ['event-id','event-name','event-date','event-category','event-desc'].forEach(id => {
    document.getElementById(id).value = '';
  });
});
</script>
<!-- Families Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Families
      <button type="button" class="btn-add-member" id="btnAddFamily" title="Add New Family">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Maintain family records and primary contacts.</p>
    </div>
  </div>
</div>
<!-- Members Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Members
      <!-- Plus button with dropdown -->
      <div class="dropdown">
        <button 
          type="button" 
          class="btn-add-member dropdown-toggle" 
          id="btnAddMember" 
          title="Add New Member"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <i class="bi bi-plus-circle-fill"></i>
        </button>
        <ul class="dropdown-menu" aria-labelledby="btnAddMember">
          <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#baptismalModal">Baptismal Records</a></li>
          <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#childDedicationModal">Child Dedication Records</a></li>
          <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#weddingModal">Wedding Records</a></li>
          <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#deathModal">Death Records</a></li>
        </ul>
      </div>
  <!-- New button to view all records -->
  <button 
    type="button" 
    class="btn btn-sm btn-primary ms-2" 
    id="btnViewAllRecords" 
    data-bs-toggle="modal" 
    data-bs-target="#recordModal"
    title="View All Records"
  >
    <i class="bi bi-list"></i> View All
  </button>
    </div>
    
    <div class="modal fade" id="recordModal" tabindex="-1" aria-labelledby="recordModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="recordModalLabel">All Records</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p class="text-muted">Loading records...</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


    <div class="card-body">
    <table class="table table-bordered table-hover">
        <thead class="table-light" style="font-size: 0.55rem;">
            <tr>
                <th>#</th>
                <th>Type</th>
                <th>Name</th>
                <th>Dt</th>
                <th>Loc</th>
                <th>Offic Past</th>
                <th>Rmrks</th>
            </tr>
        </thead>
        <tbody style="font-size: 0.55rem;">
            <?php
            $recordsStmt = $pdo->query("
                SELECT
                    id,
                    record_type,
                    name,
                    date,
                    location,
                    officiating_pastor,
                    remarks
                FROM records
                ORDER BY date DESC
                LIMIT 2
            ");
            $records = $recordsStmt->fetchAll(); // Fetch all records at once

            if (count($records) > 0): // Check if there are any records
                foreach ($records as $row):
                    echo '<tr>'
                        . '<td>' . $row['id'] . '</td>'
                        . '<td>' . $row['record_type'] . '</td>'
                        . '<td>' . htmlspecialchars($row['name']) . '</td>'
                        . '<td>' . htmlspecialchars($row['date']) . '</td>'
                        . '<td>' . htmlspecialchars($row['location']) . '</td>'
                        . '<td>' . htmlspecialchars($row['officiating_pastor']) . '</td>'
                        . '<td>' . htmlspecialchars($row['remarks']) . '</td>'
                        . '</tr>';
                endforeach;
            else: // If no records are found
                echo '<tr><td colspan="6" class="text-center text-muted">No records found.</td></tr>';
            endif;
            ?>
        </tbody>
    </table>
</div>
  </div>
</div>

<script>
// JavaScript to fetch and display records dynamically
document.getElementById('btnViewAllRecords').addEventListener('click', function () {
  const modalBody = document.querySelector('#recordModal .modal-body');
  modalBody.innerHTML = '<p class="text-muted">Loading records...</p>'; // Show loading message

  fetch('fetch_records.php?type=all') // Fetch all records
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        let table = document.createElement('table');
        table.className = 'table table-bordered table-hover';
        table.innerHTML = `
<thead>
  <tr>
    <th>#</th>
    <th>Record Type</th>
    <th>Name</th>
    <th>Date</th>
    <th>Location</th>
    <th>Pastor</th>
    <th>Remarks</th>
    <th>Membership Status</th>
  </tr>
</thead>
<tbody>
  ${data.map(record => `
    <tr>
      <td>${record.id}</td>
      <td>${record.record_type}</td>
      <td>${record.name}</td>
      <td>${record.date}</td>
      <td>${record.location}</td>
      <td>${record.pastor}</td>
      <td>${record.remarks}</td>
      <td>
         <button 
          class="btn btn-sm ${record.membership_status === 'active' ? 'btn-success' : 'btn-danger'} toggle-status-btn" 
          data-id="${record.member_id}" 
          data-status="${record.membership_status}">
          ${record.membership_status === 'active' ? 'Deactivate' : 'Activate'}
        </button>
      </td>
    </tr>
  `).join('')}
</tbody>
        `;
        modalBody.innerHTML = ''; // Clear loading message
        modalBody.appendChild(table);
      } else {
        modalBody.innerHTML = '<p class="text-muted">No records found.</p>';
      }
    })
    .catch(error => {
      console.error('Error fetching records:', error);
      modalBody.innerHTML = '<p class="text-danger">Failed to load records.</p>';
    });
});
</script>

<script>
document.querySelector('#recordModal .modal-body').addEventListener('click', function (event) {
    if (event.target.classList.contains('toggle-status-btn')) {
        const button = event.target;
        const memberId = button.getAttribute('data-id');
        const currentStatus = button.getAttribute('data-status');
        const newStatus = currentStatus === 'active' ? 'inactive' : 'active';

        console.log('Member ID:', memberId); // Debugging
        console.log('Current Status:', currentStatus); // Debugging
        console.log('New Status:', newStatus); // Debugging

        // Send AJAX request to update the status
        fetch('update_membership_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                member_id: memberId,
                status: newStatus,
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update the button text and status
                button.textContent = newStatus === 'active' ? 'Deactivate' : 'Activate';
                button.className = `btn btn-sm ${newStatus === 'active' ? 'btn-success' : 'btn-danger'} toggle-status-btn`;
                button.setAttribute('data-status', newStatus);
                alert('Membership status updated successfully.');
            } else {
                alert(`Failed to update membership status: ${data.error}`);
            }
        })
        .catch(error => console.error('Error:', error));
    }
});
</script>

<!-- Modals for Each Record Type -->
<!-- Baptismal Modal -->
<div class="modal fade" id="baptismalModal" tabindex="-1" aria-labelledby="baptismalModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <form action="save_record.php" method="POST" class="modal-content">
  <input type="hidden" name="record_type" value="Baptismal">

      <div class="modal-header">
        <h5 class="modal-title" id="baptismalModalLabel">Add Baptismal Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
      <input type="hidden" id="baptismalMemberId" name="member_id">
    <label for="baptismalName" class="form-label">Name</label>
    <input type="text" class="form-control" id="baptismalName" name="name" placeholder="Search Name" autocomplete="off" required>
    <ul class="list-group mt-2" id="baptismalNameSuggestions" style="display: none;"></ul>
</div>
        <div class="mb-3">
          <label for="baptismal-date" class="form-label">Date</label>
          <input type="date" class="form-control" id="baptismal-date" name="date" required>
        </div>
        <div class="mb-3">
          <label for="baptismal-location" class="form-label">Location</label>
          <input type="text" class="form-control" id="baptismal-location" name="location" required>
        </div>
        <div class="mb-3">
          <label for="baptismal-pastor" class="form-label">Officiating Pastor</label>
          <input type="text" class="form-control" id="baptismal-pastor" name="pastor" required>
        </div>
        <div class="mb-3">
          <label for="baptismal-remarks" class="form-label">Remarks</label>
          <textarea class="form-control" id="baptismal-remarks" name="remarks" rows="3"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Record</button>
      </div>
    </form>
  </div>
</div>
<script src="scripts/script-baptistmal.js"></script>
<!-- Child Dedication Modal -->
<div class="modal fade" id="childDedicationModal" tabindex="-1" aria-labelledby="childDedicationModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="save_record.php" method="POST" class="modal-content">
      <input type="hidden" name="record_type" value="Child Dedication">
      <input type="hidden" id="childDedicationMemberId" name="member_id">

      <div class="modal-header">
        <h5 class="modal-title" id="childDedicationModalLabel">Add Child Dedication Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="childDedicationName" class="form-label">Name</label>
          <input type="text" class="form-control" id="childDedicationName" name="name" placeholder="Search Name" autocomplete="off" required>
          <ul class="list-group mt-2" id="childDedicationNameSuggestions" style="display: none;"></ul>
        </div>
        <div class="mb-3">
          <label for="childDedicationDate" class="form-label">Date</label>
          <input type="date" class="form-control" id="childDedicationDate" name="date" required>
        </div>
        <div class="mb-3">
          <label for="childDedicationLocation" class="form-label">Location</label>
          <input type="text" class="form-control" id="childDedicationLocation" name="location" required>
        </div>
        <div class="mb-3">
          <label for="childDedicationPastor" class="form-label">Officiating Pastor</label>
          <input type="text" class="form-control" id="childDedicationPastor" name="pastor" required>
        </div>
        <div class="mb-3">
          <label for="childDedicationRemarks" class="form-label">Remarks</label>
          <textarea class="form-control" id="childDedicationRemarks" name="remarks" rows="3"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Record</button>
      </div>
    </form>
  </div>
</div>

<script src="scripts/script-child.js"></script>

</script>

<!-- Wedding Modal -->
<div class="modal fade" id="weddingModal" tabindex="-1" aria-labelledby="weddingModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="save_record.php" method="POST" class="modal-content">
      <input type="hidden" name="record_type" value="Wedding">
      <input type="hidden" id="weddingMemberId" name="member_id">

      <div class="modal-header">
        <h5 class="modal-title" id="weddingModalLabel">Add Wedding Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="weddingName" class="form-label">Name</label>
          <input type="text" class="form-control" id="weddingName" name="name" placeholder="Search Name" autocomplete="off" required>
          <ul class="list-group mt-2" id="weddingNameSuggestions" style="display: none;"></ul>
        </div>
        <div class="mb-3">
          <label for="weddingDate" class="form-label">Date</label>
          <input type="date" class="form-control" id="weddingDate" name="date" required>
        </div>
        <div class="mb-3">
          <label for="weddingLocation" class="form-label">Location</label>
          <input type="text" class="form-control" id="weddingLocation" name="location" required>
        </div>
        <div class="mb-3">
          <label for="weddingPastor" class="form-label">Officiating Pastor</label>
          <input type="text" class="form-control" id="weddingPastor" name="pastor" required>
        </div>
        <div class="mb-3">
          <label for="weddingRemarks" class="form-label">Remarks</label>
          <textarea class="form-control" id="weddingRemarks" name="remarks" rows="3"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Record</button>
      </div>
    </form>
  </div>
</div>

<script src="scripts/script-wedding.js"></script>

<!-- Death Modal -->
<div class="modal fade" id="deathModal" tabindex="-1" aria-labelledby="deathModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="save_record.php" method="POST" class="modal-content">
      <input type="hidden" name="record_type" value="Death">
      <input type="hidden" id="deathMemberId" name="member_id">

      <div class="modal-header">
        <h5 class="modal-title" id="deathModalLabel">Add Death Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="deathName" class="form-label">Name</label>
          <input type="text" class="form-control" id="deathName" name="name" placeholder="Search Name" autocomplete="off" required>
          <ul class="list-group mt-2" id="deathNameSuggestions" style="display: none;"></ul>
        </div>
        <div class="mb-3">
          <label for="deathDate" class="form-label">Date</label>
          <input type="date" class="form-control" id="deathDate" name="date" required>
        </div>
        <div class="mb-3">
          <label for="deathLocation" class="form-label">Location</label>
          <input type="text" class="form-control" id="deathLocation" name="location" required>
        </div>
        <div class="mb-3">
          <label for="deathPastor" class="form-label">Officiating Pastor</label>
          <input type="text" class="form-control" id="deathPastor" name="pastor" required>
        </div>
        <div class="mb-3">
          <label for="deathRemarks" class="form-label">Remarks</label>
          <textarea class="form-control" id="deathRemarks" name="remarks" rows="3"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Record</button>
      </div>
    </form>
  </div>
</div>

<script src="scripts/script-death.js"></script>

<script>
  // Enable dropdown on hover
  const btnAddMember = document.getElementById('btnAddMember');
  const dropdownMenu = btnAddMember.nextElementSibling;

  let dropdownTimeout;

  // Show dropdown on hover
  btnAddMember.addEventListener('mouseenter', () => {
    clearTimeout(dropdownTimeout); // Clear any existing timeout
    dropdownMenu.classList.add('show');
    btnAddMember.setAttribute('aria-expanded', 'true');
  });

  dropdownMenu.addEventListener('mouseenter', () => {
    clearTimeout(dropdownTimeout); // Keep dropdown open when hovering over it
    dropdownMenu.classList.add('show');
    btnAddMember.setAttribute('aria-expanded', 'true');
  });

  // Hide dropdown when mouse leaves button or menu
  btnAddMember.addEventListener('mouseleave', () => {
    dropdownTimeout = setTimeout(() => {
      dropdownMenu.classList.remove('show');
      btnAddMember.setAttribute('aria-expanded', 'false');
    }, 200); // Add a small delay to allow interaction
  });

  dropdownMenu.addEventListener('mouseleave', () => {
    dropdownTimeout = setTimeout(() => {
      dropdownMenu.classList.remove('show');
      btnAddMember.setAttribute('aria-expanded', 'false');
    }, 200); // Add a small delay to allow interaction
  });
</script>
<!-- Member Department Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Member Department
      <!-- Add button -->
      <button 
        type="button" 
        class="btn-add-member" 
        id="btnAddMemberDepartment" 
        data-bs-toggle="modal" 
        data-bs-target="#addMemberDepartmentModal" 
        title="Add New Member Department">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
      <!-- View button -->
      <button 
        type="button" 
        class="btn-add-member ms-2" 
        id="btnViewMemberDepartment" 
        data-bs-toggle="modal" 
        data-bs-target="#viewMemberDepartmentModal" 
        title="View Member Departments">
        <i class="bi bi-list-ul"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Organize members into various departments.</p>
    </div>
  </div>
</div>
<!-- Add Member Department Modal -->
<div class="modal fade" id="addMemberDepartmentModal" tabindex="-1" aria-labelledby="addMemberDepartmentLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="save_member_department.php" method="POST" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addMemberDepartmentLabel">Add Member Department</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<!-- filepath: c:\xampp\htdocs\ChurchHub\dashboard.php -->
<div class="mb-3">
  <label for="memberName" class="form-label">Member Name</label>
  <select class="form-select" id="memberName" name="member_name" required>
    <option value="" disabled selected>-- Select Member --</option>
    <?php foreach ($members as $m): ?>
      <option value="<?= htmlspecialchars($m['first_name'] . ' ' . $m['middle_name'] . ' ' . $m['last_name']) ?>">
        <?= htmlspecialchars($m['first_name'] . ' ' . $m['middle_name'] . ' ' . $m['last_name']) ?>
      </option>
    <?php endforeach; ?>
  </select>
</div>
        <div class="mb-3">
          <label for="departmentName" class="form-label">Department</label>
          <input type="text" class="form-control" id="departmentName" name="department_name" placeholder="Enter department name" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- View Member Departments Modal -->
<div class="modal fade" id="viewMemberDepartmentModal" tabindex="-1" aria-labelledby="viewMemberDepartmentLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewMemberDepartmentLabel">Member Departments</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Search Member Name -->
        <div class="mb-3">
          <input type="text" class="form-control" id="searchMemberDepartment" placeholder="Search Member Name...">
        </div>
        <table class="table table-bordered table-hover" id="memberDepartmentTable">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Member Name</th>
              <th>Department</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $departmentsStmt = $pdo->query("
              SELECT id, member_name, department_name 
              FROM member_departments 
              ORDER BY id DESC
            ");
            while ($row = $departmentsStmt->fetch(PDO::FETCH_ASSOC)) {
              echo '<tr>'
                . '<td>' . $row['id'] . '</td>'
                . '<td>' . htmlspecialchars($row['member_name']) . '</td>'
                . '<td>' . htmlspecialchars($row['department_name']) . '</td>'
                . '</tr>';
            }
            ?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script>
// Simple client-side search for member name in the table
document.addEventListener('DOMContentLoaded', function () {
  const searchInput = document.getElementById('searchMemberDepartment');
  const table = document.getElementById('memberDepartmentTable');
  if (searchInput && table) {
    searchInput.addEventListener('keyup', function () {
      const filter = searchInput.value.toLowerCase();
      const rows = table.querySelectorAll('tbody tr');
      rows.forEach(row => {
        const memberName = row.children[1].textContent.toLowerCase();
        row.style.display = memberName.includes(filter) ? '' : 'none';
      });
    });
  }
});
</script>
       <!-- Member Families Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Member Families
      <button type="button" class="btn-add-member" id="btnAddMemberFamily" title="Add New Member Family">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Link members to their respective families.</p>
    </div>
  </div>
</div>
<!-- Member Ministries Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Member Ministries
      <button type="button" class="btn-add-member" id="btnAddMemberMinistry" title="Add New Member Ministry">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Assign members to various ministries.</p>
    </div>
  </div>
</div>
<!-- Ministries Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Ministries
      <button type="button" class="btn-add-member" id="btnAddMinistry" title="Add New Ministry">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Oversee ministry details and descriptions.</p>
    </div>
  </div>
</div>
<!-- Volunteer Assignments Module -->
<div class="col-sm-6 col-lg-4">
  <div class="card">
    <div class="card-header">
      Volunteer Assignments
      <button type="button" class="btn-add-member" id="btnAddVolunteerAssignment" title="Add New Volunteer Assignment">
        <i class="bi bi-plus-circle-fill"></i>
      </button>
    </div>
    <div class="card-body">
      <p class="card-text">Manage volunteer roles and assignment dates.</p>
    </div>
  </div>
</div>
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </main>
  
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // wire up the "add member" button
    document.getElementById('btnAddMember').addEventListener('click', function() {
      // TODO: replace with your modal-show or navigation logic
      console.log('Add Member button clicked!');
      // e.g.: window.location.href = 'members-create.html';
      // or: new bootstrap.Modal(document.getElementById('createMemberModal')).show();
    });
  </script>
</body>
</html>
