<?php
session_start();
require_once 'db.php';
require 'db.php';
$settings = [
    'church_name' => 'ChurchHub',
    'church_address' => '123 Church Street, Cityville, Country',
    'contact_email' => 'example@church.com',
    'contact_phone' => '+1 234 567 890',
    'logo_path' => null
];
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings = array_merge($settings, $row);
}

// fetch all upcoming events
$stmt = $pdo->query("SELECT * FROM events ORDER BY event_date ASC");
$events = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ChurchHub - Events</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <script src="scripts/script.js"></script>

  <style>
    body {
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }
    /* Fixed Sidebar */
    .sidebar {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: 250px;
      background: #343a40;
      color: #fff;
      overflow-y: auto;
      padding: 1rem 0;
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }
    .sidebar .brand {
      text-align: center;
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      font-weight: bold;
    }
    .sidebar .nav-link {
      color: #adb5bd;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s, color 0.3s;
    }
    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background: #495057;
      color: #fff;
    }
    .sidebar hr {
      border-color: rgba(255, 255, 255, 0.1);
    }
    /* Main Content */
    .main-content {
      margin-left: 250px;
      padding: 2rem;
    }
    .upcoming-events-section {
      background: #fff;
      border-radius: 0.5rem;
      padding: 1.5rem;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }
    .upcoming-events-section h2 {
      font-size: 1.5rem;
      margin-bottom: 1rem;
    }
    .event-card {
      background: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 0.5rem;
      margin-bottom: 1rem;
      padding: 1rem;
      transition: background 0.3s, transform 0.3s;
    }
    .event-card:hover {
      background: #e9ecef;
      transform: translateY(-2px);
    }
    .event-title {
      font-weight: bold;
      margin: 0 0 0.5rem 0;
    }
    .event-meta {
      font-size: 0.9rem;
      color: #6c757d;
    }
    .event-desc {
      font-size: 0.85rem;
      color: #495057;
      margin-top: 0.5rem;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 200px;
      }
      .main-content {
        margin-left: 200px;
      }
    }
  </style>
</head>
<body>
   <!-- Sidebar -->
<!-- Add IDs to the sidebar links -->
<nav class="sidebar">

<div class="brand text-center">
  <div id="sidebarLogoContainer" style="width: 50px; height: 50px; background-color: #007bff; border-radius: 50%; display: inline-block; margin-bottom: 0.5rem; overflow: hidden;">
    <?php if (!empty($settings['logo_path'])): ?>
      <img id="sidebarLogoImg" src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
    <?php else: ?>
      <span id="sidebarLogoText" style="color: #fff; font-size: 1.5rem; font-weight: bold; line-height: 50px; display: inline-block;">
        <?= strtoupper(substr($settings['church_name'], 0, 2)) ?>
      </span>
    <?php endif; ?>
  </div>
  <?= htmlspecialchars($settings['church_name']) ?>
</div>
<div class="address text-center mt-2" style="font-size: 1rem; font-weight: 500; color: #fff; background-color: #343a40; padding: 0.5rem; border-radius: 0.25rem;">
  <small><?= htmlspecialchars($settings['church_address']) ?></small>
</div>
<div class="contact-details text-center mt-2" style="font-size: 0.9rem; font-weight: 500; color: #fff; background-color: #495057; padding: 0.5rem; border-radius: 0.25rem;">
  <small>Email: <?= htmlspecialchars($settings['contact_email']) ?> | Phone: <?= htmlspecialchars($settings['contact_phone']) ?></small>
</div>

  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php" id="navDashboard">
        <i class="bi bi-house-door-fill me-2"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="members.php" id="navMembers">
        <i class="bi bi-people-fill me-2"></i> Members
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="events.php" id="navEvents">
        <i class="bi bi-calendar-event-fill me-2"></i> Events
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="communications.php" id="navCommunications">
        <i class="bi bi-chat-left-text-fill me-2"></i> Communications
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="donations.php" id="navDonations">
        <i class="bi bi-cash-stack me-2"></i> Church Funds
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="settings.php" id="navSettings">
        <i class="bi bi-gear-fill me-2"></i> Settings
      </a>
    </li>
  </ul>
  <hr>
  <div class="text-center">
    <small>v1.0.0</small>
  </div>
</nav>
  
  <!-- Main Content -->
  <main class="main-content">
    <div class="container-fluid">
      <!-- Upcoming Events Section -->
<!-- flash messages -->
<?php if (!empty($_SESSION['success'])): ?>
        <div class="alert alert-success">
          <?= $_SESSION['success'] ?>
        </div>
        <?php unset($_SESSION['success']); ?>
      <?php endif; ?>

      <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger">
          <?= $_SESSION['error'] ?>
        </div>
        <?php unset($_SESSION['error']); ?>
      <?php endif; ?>

      <!-- Upcoming Events Section -->
      <section class="upcoming-events-section">
        <h2>Upcoming Events</h2>
        <div class="row">
          <?php if (count($events) === 0): ?>
            <p class="text-muted">No events scheduled.</p>
          <?php endif; ?>

          <?php foreach ($events as $e): ?>
            <div class="col-md-6 col-lg-4">
              <a href="event-details.php?event_id=<?= $e['event_id'] ?>"
                 class="text-decoration-none text-dark">
                <div class="event-card">
                  <p class="event-title">
                    <?= htmlspecialchars($e['event_name']) ?>
                  </p>
                  <p class="event-meta mb-0">
                    <i class="bi bi-calendar-date me-1"></i>
                    <?= date('F j, Y', strtotime($e['event_date'])) ?>
                  </p>
                  <p class="event-meta mb-0">
                    <i class="bi bi-geo-alt me-1"></i>
                    <?= htmlspecialchars($e['location']) ?>
                  </p>
                  <p class="event-desc">
                    <?= nl2br(htmlspecialchars($e['description'])) ?>
                  </p>
                </div>
              </a>
            </div>
          <?php endforeach; ?>
        </div>
      </section>
      
      <!-- Events Module Content -->
      <section class="events-module">
        <h1>Events Module</h1>
        <p class="text-muted">Manage event details, dates, locations, and descriptions.</p>


        <!-- Additional content or management tools can go here -->
        <div class="card p-4 mt-4">
          <h5 class="mb-3">Add New Event</h5>
          <form action="save-event.php" method="POST">
            <div class="mb-3">
              <label for="eventTitle" class="form-label">Event Title</label>
              <input type="text" class="form-control" id="eventTitle" name="event_title" required>
            </div>
            <div class="mb-3">
              <label for="eventDateTime" class="form-label">Event Date & Time</label>
              <input type="datetime-local" class="form-control" id="eventDateTime" name="event_date_time" required>
            </div>
            <div class="mb-3">
              <label for="eventLocation" class="form-label">Location</label>
              <input type="text" class="form-control" id="eventLocation" name="event_location" required>
            </div>
            <div class="mb-3">
              <label for="eventDescription" class="form-label">Description</label>
              <textarea class="form-control" id="eventDescription" name="event_description" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-save2 me-1"></i> Save Event
            </button>
          </form>
        </div>
        

          <!-- 1. Edit Existing Event -->
  <div class="card p-4 mt-4">
    <h5 class="mb-3">Edit Event</h5>
    <form action="update-event.php" method="POST">
      <!-- Hidden field carrying the event’s ID -->
      <input type="hidden" name="event_id" value="">

      <div class="mb-3">
        <label for="editTitle" class="form-label">Event Title</label>
        <input
          type="text"
          class="form-control"
          id="editTitle"
          name="event_title"
         
          required
        >
      </div>

      <div class="mb-3">
        <label for="editDate" class="form-label">Event Date</label>
        <input
          type="date"
          class="form-control"
          id="editDate"
          name="event_date"
      
          required
        >
      </div>

      <div class="mb-3">
        <label for="editLocation" class="form-label">Location</label>
        <input
          type="text"
          class="form-control"
          id="editLocation"
          name="event_location"
     
          required
        >
      </div>

      <div class="mb-3">
        <label for="editDesc" class="form-label">Description</label>
        <textarea
          class="form-control"
          id="editDesc"
          name="event_description"
          rows="4"
          required
        ></textarea>
      </div>

      <button type="submit" class="btn btn-warning">
        <i class="bi bi-pencil-square me-1"></i> Update Event
      </button>
    </form>
  </div>

  <!-- 2. Delete Event -->
  <div class="card p-4 mt-4">
    <h5 class="mb-3">Delete Event</h5>
    <form
      action="delete-event.php"
      method="POST"
      onsubmit="return confirm('Are you sure you want to delete this event?');"
    >
      <input type="hidden" name="event_id" ">
      <button type="submit" class="btn btn-danger">
        <i class="bi bi-trash-fill me-1"></i> Delete Event
      </button>
    </form>
  </div>
        
      </section>
    </div>
  </main>
  
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
