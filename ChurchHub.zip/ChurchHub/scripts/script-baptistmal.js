document.getElementById('baptismalName').addEventListener('input', function () {
    const query = this.value.trim();
    const suggestionsList = document.getElementById('baptismalNameSuggestions');

    if (query.length > 0) {
        fetch(`search_names.php?query=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                suggestionsList.innerHTML = '';
                if (data.length > 0) {
                    suggestionsList.style.display = 'block';
                    data.forEach(item => {
                        const li = document.createElement('li');
                        li.className = 'list-group-item list-group-item-action';
                        li.textContent = `${item.first_name} ${item.middle_name} ${item.last_name}`;
                        li.dataset.memberId = item.member_id; // Store member_id in the list item
                        li.addEventListener('click', () => {
                            document.getElementById('baptismalName').value = li.textContent;
                            document.getElementById('baptismalMemberId').value = li.dataset.memberId; // Set member_id in hidden input
                            suggestionsList.style.display = 'none';
                        });
                        suggestionsList.appendChild(li);
                    });
                } else {
                    suggestionsList.style.display = 'none';
                }
            })
            .catch(error => console.error('Error fetching names:', error));
    } else {
        suggestionsList.style.display = 'none';
    }
});