
document.addEventListener('DOMContentLoaded', function () {
  // Define corresponding sidebar links
  const sidebarLinks = {
    enableAttendance: document.getElementById('navEvents'),
    enableDonations: document.getElementById('navDonations'),
    enableCommunications: document.getElementById('navCommunications'),
    enableEvents: document.getElementById('navEvents'),
  };

  // Function to update sidebar visibility based on localStorage
  function updateSidebar() {
    for (const [key, link] of Object.entries(sidebarLinks)) {
      const savedState = localStorage.getItem(key);
      if (link) {
        link.style.display = savedState === 'true' ? 'block' : 'none';
      }
    }
  }

  // Initial setup
  updateSidebar();
});

  document.addEventListener('DOMContentLoaded', function () {
    // Get the current page's filename
    const currentPage = window.location.pathname.split('/').pop();

    // Get all sidebar links
    const sidebarLinks = document.querySelectorAll('.sidebar .nav-link');

    // Loop through the links and set the active class
    sidebarLinks.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  });
