<?php
// members.php

// 1. Database connection
$host     = 'localhost';
$dbname   = 'churchhub';
$user     = 'root';
$password = '';


try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// 2. Collect and sanitize POST data
$first_name        = $_POST['first_name']        ?? '';
$middle_name       = $_POST['middle_name']       ?? '';
$last_name         = $_POST['last_name']         ?? '';
$date_of_birth     = $_POST['date_of_birth']     ?? '';
$place_of_birth    = $_POST['place_of_birth']    ?? '';
$citizenship       = $_POST['citizenship']       ?? '';
$gender            = $_POST['Gender']            ?? '';
$civil_status      = $_POST['civil-status']      ?? '';
// normalize empty string to null so we insert SQL NULL
$email = trim($_POST['email'] ?? '') ?: null;

$phone             = $_POST['phone']             ?? '';
$facebook_account  = $_POST['facebook-account']  ?? '';
$spouse_last       = $_POST['last-name-of-spouse']   ?? null;
$spouse_first      = $_POST['first-name-of-spouse']  ?? null;
$spouse_middle     = $_POST['middle-name-of-spouse'] ?? null;
$spouse_dob        = $_POST['spouse_date_of_birth']  ?? null;  // note: your form uses duplicate name date_of_birth—rename one!
$date_of_marriage  = $_POST['date_of_marriage']  ?? null;
$place_of_marriage = $_POST['place_of_marriage'] ?? null;
$year_of_membership= $_POST['year-of-membership'] ?? '';
$ministry_position= $_POST['ministry-position-involvement'] ?? '';
$year_of_conversion= $_POST['year-of-conversion'] ?? '';
$year_of_baptism   = $_POST['year-of-water-baptism'] ?? '';
$membership_status = $_POST['membership_status'] ?? '';
$previous_religion = $_POST['previous-religion'] ?? '';
$previous_church   = $_POST['previous-christian-church-if-any'] ?? '';
$address           = $_POST['address'] ?? '';

// Arrays
$spiritual_gifts   = $_POST['spiritual_gifts']   ?? [];
$skills            = $_POST['skills']            ?? [];
$sports_hobbies    = $_POST['sports_hobbies']    ?? [];
$health_profile    = $_POST['health_profile']    ?? [];

// Children
$children = [];
foreach ($_POST as $k => $v) {
    if (preg_match('/^child_name_(\d+)$/', $k, $m)) {
        $children[] = $v;
    }
}

// Education
$education = [];
for ($i = 1; $i <= 5; $i++) {
    if (!empty($_POST["school_name_$i"])) {
        $education[] = [
            'school' => $_POST["school_name_$i"],
            'year'   => $_POST["year_graduated_$i"],
            'course' => $_POST["course_degree_$i"],
        ];
    }
}

// Trainings
$trainings = [];
for ($i = 1; $i <= 5; $i++) {
    if (!empty($_POST["training_name_$i"])) {
        $trainings[] = [
            'training'    => $_POST["training_name_$i"],
            'year_taken'  => $_POST["year_taken_$i"],
            'designation' => $_POST["title_designation_$i"],
        ];
    }
}
// 3. Check for unique email
if ($email) {
    $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM members WHERE email = :email");
    $stmtCheck->execute([':email' => $email]);
    if ($stmtCheck->fetchColumn() > 0) {
        die("<script>alert('Email address already exists. Please use a different email.'); window.history.back();</script>");
    }
}

// 3. Begin transaction
$pdo->beginTransaction();

try {
    // 4. Insert into members table
    $stmt = $pdo->prepare("
        INSERT INTO members 
          (first_name, middle_name, last_name, date_of_birth, place_of_birth, citizenship,
           gender, civil_status, email, phone, facebook_account,
           spouse_last, spouse_first, spouse_middle, spouse_dob,
           date_of_marriage, place_of_marriage,
           year_of_membership, ministry_position, year_of_conversion, year_of_baptism,
           membership_status, previous_religion, previous_church, address)
        VALUES 
          (:first, :middle, :last, :dob, :pob, :citizenship,
           :gender, :civil, :email, :phone, :fb,
           :s_last, :s_first, :s_middle, :s_dob,
           :dom, :pom,
           :yom, :minpos, :yoc, :yob,
           :status, :prev_rel, :prev_church, :addr)
    ");
    $stmt->execute([
        ':first'        => $first_name,
        ':middle'       => $middle_name,
        ':last'         => $last_name,
        ':dob'          => $date_of_birth,
        ':pob'          => $place_of_birth,
        ':citizenship'  => $citizenship,
        ':gender'       => $gender,
        ':civil'        => $civil_status,
        ':email'        => $email,
        ':phone'        => $phone,
        ':fb'           => $facebook_account,
        ':s_last'       => $spouse_last,
        ':s_first'      => $spouse_first,
        ':s_middle'     => $spouse_middle,
        ':s_dob'        => $spouse_dob,
        ':dom'          => $date_of_marriage,
        ':pom'          => $place_of_marriage,
        ':yom'          => $year_of_membership,
        ':minpos'       => $ministry_position,
        ':yoc'          => $year_of_conversion,
        ':yob'          => $year_of_baptism,
        ':status'       => $membership_status,
        ':prev_rel'     => $previous_religion,
        ':prev_church'  => $previous_church,
        ':addr'         => $address
    ]);
    $member_id = $pdo->lastInsertId();

    // 5. Insert repeating groups
    // 5a. Spiritual gifts
    $stmtGift = $pdo->prepare("INSERT INTO member_gifts (member_id, gift) VALUES (:mid, :gift)");
    foreach ($spiritual_gifts as $g) {
        $stmtGift->execute([':mid' => $member_id, ':gift' => $g]);
    }

    // 5b. Skills
    $stmtSkill = $pdo->prepare("INSERT INTO member_skills (member_id, skill) VALUES (:mid, :skill)");
    foreach ($skills as $s) {
        $stmtSkill->execute([':mid' => $member_id, ':skill' => $s]);
    }

    // 5c. Hobbies/Sports
    $stmtHobby = $pdo->prepare("INSERT INTO member_hobbies (member_id, hobby) VALUES (:mid, :hobby)");
    foreach ($sports_hobbies as $h) {
        $stmtHobby->execute([':mid' => $member_id, ':hobby' => $h]);
    }

    // 5d. Health profile
    $stmtHealth = $pdo->prepare("INSERT INTO member_health (member_id, condition_name) VALUES (:mid, :cond)");
    foreach ($health_profile as $c) {
        $stmtHealth->execute([':mid' => $member_id, ':cond' => $c]);
    }

    // 5e. Children
    $stmtChild = $pdo->prepare("INSERT INTO member_children (member_id, child_name) VALUES (:mid, :cname)");
    foreach ($children as $cname) {
        $stmtChild->execute([':mid' => $member_id, ':cname' => $cname]);
    }

    // 5f. Education
    $stmtEdu = $pdo->prepare("
        INSERT INTO member_education (member_id, school_name, year_graduated, course_degree)
        VALUES (:mid, :school, :year, :course)
    ");
    foreach ($education as $ed) {
        $stmtEdu->execute([
            ':mid'   => $member_id,
            ':school'=> $ed['school'],
            ':year'  => $ed['year'],
            ':course'=> $ed['course']
        ]);
    }

    // 5g. Trainings
    $stmtTr = $pdo->prepare("
        INSERT INTO member_trainings (member_id, training_name, year_taken, title_designation)
        VALUES (:mid, :training, :yt, :title)
    ");
    foreach ($trainings as $tr) {
        $stmtTr->execute([
            ':mid'     => $member_id,
            ':training'=> $tr['training'],
            ':yt'      => $tr['year_taken'],
            ':title'   => $tr['designation']
        ]);
    }

    // 6. Commit
    $pdo->commit();

    header("Location: members.php?status=success");
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    die("Error saving member: " . $e->getMessage());
}
}