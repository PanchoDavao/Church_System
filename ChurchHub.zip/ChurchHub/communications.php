<?php
require 'db.php';
$settings = [
    'church_name' => 'ChurchHub',
    'church_address' => '123 Church Street, Cityville, Country',
    'contact_email' => 'example@church.com',
    'contact_phone' => '+1 234 567 890',
    'logo_path' => null
];
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings = array_merge($settings, $row);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Communications - ChurchHub</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <script src="scripts/script.js"></script>

  <style>
    body {
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }
    /* Main Sidebar */
    .sidebar {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: 250px;
      background: #343a40;
      color: #fff;
      overflow-y: auto;
      padding: 1rem 0;
    }
    .sidebar .brand {
      text-align: center;
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      font-weight: bold;
    }
    .sidebar .nav-link {
      color: #adb5bd;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s, color 0.3s;
    }
    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background: #495057;
      color: #fff;
    }
    .sidebar hr {
      border-color: rgba(255, 255, 255, 0.1);
    }
    /* Communications Sub-Sidebar */
    .comm-sidebar {
      background: #f8f9fa;
      padding: 1rem;
      border-radius: 0.5rem;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      margin-bottom: 1rem;
    }
    .comm-sidebar .list-group-item {
      background-color: #f8f9fa;
      color: #343a40;
      border: none;
    }
    .comm-sidebar .list-group-item.active {
      background-color: #007bff;
      color: #fff;
    }
    /* Main Content */
    .main-content {
      margin-left: 250px;
      padding: 2rem;
      overflow-y: auto;
      height: 100vh;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 200px;
      }
      .main-content {
        margin-left: 200px;
      }
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <nav class="sidebar">

  <div class="brand text-center">
  <div id="sidebarLogoContainer" style="width: 50px; height: 50px; background-color: #007bff; border-radius: 50%; display: inline-block; margin-bottom: 0.5rem; overflow: hidden;">
    <?php if (!empty($settings['logo_path'])): ?>
      <img id="sidebarLogoImg" src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
    <?php else: ?>
      <span id="sidebarLogoText" style="color: #fff; font-size: 1.5rem; font-weight: bold; line-height: 50px; display: inline-block;">
        <?= strtoupper(substr($settings['church_name'], 0, 2)) ?>
      </span>
    <?php endif; ?>
  </div>
  <?= htmlspecialchars($settings['church_name']) ?>
</div>
<div class="address text-center mt-2" style="font-size: 1rem; font-weight: 500; color: #fff; background-color: #343a40; padding: 0.5rem; border-radius: 0.25rem;">
  <small><?= htmlspecialchars($settings['church_address']) ?></small>
</div>
<div class="contact-details text-center mt-2" style="font-size: 0.9rem; font-weight: 500; color: #fff; background-color: #495057; padding: 0.5rem; border-radius: 0.25rem;">
  <small>Email: <?= htmlspecialchars($settings['contact_email']) ?> | Phone: <?= htmlspecialchars($settings['contact_phone']) ?></small>
</div>

    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php" id="navDashboard">
          <i class="bi bi-house-door-fill me-2"></i> Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="members.php" id="navMembers">
          <i class="bi bi-people-fill me-2"></i> Members
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="events.php" id="navEvents">
          <i class="bi bi-calendar-event-fill me-2"></i> Events
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="communications.php" id="navCommunications">
          <i class="bi bi-chat-left-text-fill me-2"></i> Communications
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="donations.php" id="navDonations">
          <i class="bi bi-cash-stack me-2"></i> Church Funds
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="settings.php" id="navSettings">
          <i class="bi bi-gear-fill me-2"></i> Settings
        </a>
      </li>
    </ul>
    <hr>
    <div class="text-center">
      <small>v1.0.0</small>
    </div>
  </nav>
  
  <!-- Main Content for Communications Module -->
  <main class="main-content">
    <div class="container-fluid">
      <h1 class="mb-4">Communications</h1>
      <div class="row">
        <!-- Communications Sub-Sidebar -->
        <div class="col-md-3">
          <div class="comm-sidebar">
            <div class="list-group">
              <a href="communications-inbox.html" class="list-group-item list-group-item-action">
                <i class="bi bi-inbox-fill me-2"></i> Inbox
              </a>
              <a href="" class="list-group-item list-group-item-action active">
                <i class="bi bi-send-fill me-2"></i> Sent
              </a>
              <a href="communications-compose.html" class="list-group-item list-group-item-action">
                <i class="bi bi-pencil-square me-2"></i> Compose
              </a>
              <a href="communications-trash.html" class="list-group-item list-group-item-action">
                <i class="bi bi-trash-fill me-2"></i> Trash
              </a>
            </div>
          </div>
        </div>
        <!-- Communications Content Area -->
        <div class="col-md-9">
          <div class="card">
            <div class="card-header">Sent Messages</div>
            <div class="card-body">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Subject</th>
                    <th scope="col">Type</th>
                    <th scope="col">Date Sent</th>
                    <th scope="col">Recipients</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- Sample rows; replace with dynamic content -->
                  <tr>
                    <td>Event Follow-Up</td>
                    <td>Notification</td>
                    <td>2025-04-02 11:15 AM</td>
                    <td>All Attendees</td>
                  </tr>
                  <tr>
                    <td>Monthly Newsletter</td>
                    <td>Newsletter</td>
                    <td>2025-04-01 09:00 AM</td>
                    <td>Subscribers List</td>
                  </tr>
                  <!-- Additional rows as needed -->
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </main>
  
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
