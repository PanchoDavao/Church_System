<?php
require 'db.php';

$type = $_GET['type'] ?? 'all';

if ($type === 'all') {
    $stmt = $pdo->query("
        SELECT 
            r.id,
            r.record_type,
            r.name,
            r.date,
            r.location,
            r.officiating_pastor AS pastor,
            r.remarks,
            m.member_id,
            m.membership_status
        FROM records r
        LEFT JOIN members m ON r.member_id = m.member_id
        ORDER BY r.date DESC
    ");
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($records);
}
?>