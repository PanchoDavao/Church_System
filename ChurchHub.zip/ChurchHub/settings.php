<?php
require 'db.php';
$settings = [
    'church_name' => 'ChurchHub',
    'church_address' => '123 Church Street, Cityville, Country',
    'contact_email' => 'example@church.com',
    'contact_phone' => '+1 234 567 890',
    'logo_path' => null
];
$stmt = $pdo->query("SELECT * FROM settings WHERE id = 1 LIMIT 1");
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings = array_merge($settings, $row);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ChurchHub Settings</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <!-- Add JavaScript to handle the visibility -->
<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Define module preferences and corresponding sidebar links
    const modulePreferences = {
      enableDonations: document.getElementById('enableDonations'),
      enableCommunications: document.getElementById('enableCommunications'),
      enableEvents: document.getElementById('enableEvents'),
    };

    const sidebarLinks = {
      enableAttendance: document.getElementById('navEvents'),
      enableDonations: document.getElementById('navDonations'),
      enableCommunications: document.getElementById('navCommunications'),
      enableEvents: document.getElementById('navEvents'),
    };

    // Load preferences from localStorage
    function loadPreferences() {
      for (const [key, checkbox] of Object.entries(modulePreferences)) {
        const savedState = localStorage.getItem(key);
        if (savedState !== null) {
          checkbox.checked = savedState === 'true';
        }
      }
    }

    // Save preferences to localStorage
    function savePreferences() {
      for (const [key, checkbox] of Object.entries(modulePreferences)) {
        localStorage.setItem(key, checkbox.checked);
      }
    }

    // Function to update sidebar visibility
    function updateSidebar() {
      for (const [key, checkbox] of Object.entries(modulePreferences)) {
        const link = sidebarLinks[key];
        if (checkbox && link) {
          link.style.display = checkbox.checked ? 'block' : 'none';
        }
      }
    }

    // Add event listeners to checkboxes
    for (const checkbox of Object.values(modulePreferences)) {
      if (checkbox) {
        checkbox.addEventListener('change', () => {
          savePreferences();
          updateSidebar();
        });
      }
    }

    // Initial setup
    loadPreferences();
    updateSidebar();
  });
</script>


  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Get the current page's filename
      const currentPage = window.location.pathname.split('/').pop();
  
      // Get all sidebar links
      const sidebarLinks = document.querySelectorAll('.sidebar .nav-link');
  
      // Loop through the links and set the active class
      sidebarLinks.forEach(link => {
        if (link.getAttribute('href') === currentPage) {
          link.classList.add('active');
        } else {
          link.classList.remove('active');
        }
      });
    });
  </script>

  <style>
    body {
      background-color: #f4f6f9;
      font-family: Arial, sans-serif;
    }
    /* Fixed Sidebar */
    .sidebar {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: 250px;
      background: #343a40;
      color: #fff;
      padding: 1rem 0;
      overflow-y: auto;
    }
    .sidebar .brand {
      text-align: center;
      font-size: 1.5rem;
      font-weight: bold;
      margin-bottom: 1.5rem;
    }
    .sidebar .nav-link {
      color: #adb5bd;
      padding: 0.75rem 1.5rem;
      transition: background 0.3s, color 0.3s;
    }
    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background: #495057;
      color: #fff;
    }
    .sidebar hr {
      border-color: rgba(255, 255, 255, 0.1);
    }
    /* Main Content */
    .main-content {
      margin-left: 250px;
      padding: 2rem;
    }
    .section-header {
      margin-top: 1rem;
      margin-bottom: 1rem;
      border-bottom: 2px solid #007bff;
      padding-bottom: 0.5rem;
      font-weight: 600;
      color: #007bff;
    }
    .card {
      border: none;
      border-radius: 0.5rem;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      margin-bottom: 1.5rem;
    }
    .card-header {
      background-color: #007bff;
      color: #fff;
      border-top-left-radius: 0.5rem;
      border-top-right-radius: 0.5rem;
      font-size: 1.1rem;
      font-weight: bold;
    }
    .card-body {
      background-color: #fff;
    }
    @media (max-width: 768px) {
      .sidebar {
        width: 200px;
      }
      .main-content {
        margin-left: 200px;
      }
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
<!-- Add IDs to the sidebar links -->
<nav class="sidebar">
<div class="brand text-center">
  <div id="sidebarLogoContainer" style="width: 50px; height: 50px; background-color: #007bff; border-radius: 50%; display: inline-block; margin-bottom: 0.5rem; overflow: hidden;">
    <?php if (!empty($settings['logo_path'])): ?>
      <img id="sidebarLogoImg" src="data:image/png;base64,<?= base64_encode($settings['logo_path']) ?>" alt="Logo" style="width: 100%; height: 100%; object-fit: cover;">
    <?php else: ?>
      <span id="sidebarLogoText" style="color: #fff; font-size: 1.5rem; font-weight: bold; line-height: 50px; display: inline-block;">
        <?= strtoupper(substr($settings['church_name'], 0, 2)) ?>
      </span>
    <?php endif; ?>
  </div>
  <?= htmlspecialchars($settings['church_name']) ?>
</div>
<div class="address text-center mt-2" style="font-size: 1rem; font-weight: 500; color: #fff; background-color: #343a40; padding: 0.5rem; border-radius: 0.25rem;">
  <small><?= htmlspecialchars($settings['church_address']) ?></small>
</div>
<div class="contact-details text-center mt-2" style="font-size: 0.9rem; font-weight: 500; color: #fff; background-color: #495057; padding: 0.5rem; border-radius: 0.25rem;">
  <small>Email: <?= htmlspecialchars($settings['contact_email']) ?> | Phone: <?= htmlspecialchars($settings['contact_phone']) ?></small>
</div>
  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php" id="navDashboard">
        <i class="bi bi-house-door-fill me-2"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="members.php" id="navMembers">
        <i class="bi bi-people-fill me-2"></i> Members
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="events.php" id="navEvents">
        <i class="bi bi-calendar-event-fill me-2"></i> Events
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="communications.php" id="navCommunications">
        <i class="bi bi-chat-left-text-fill me-2"></i> Communications
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="donations.php" id="navDonations">
        <i class="bi bi-cash-stack me-2"></i> Church Funds
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="settings.php" id="navSettings">
        <i class="bi bi-gear-fill me-2"></i> Settings
      </a>
    </li>
  </ul>
  <hr>
  <div class="text-center">
    <small>v1.0.0</small>
  </div>
</nav>


  <!-- Main Content -->
  <main class="main-content">
    <h1 class="mb-4">System Settings</h1>
    <p class="text-muted mb-4">Configure your ChurchHub system settings based on your organizational requirements.</p>

    <!-- General Settings -->
    <div class="card">
      <div class="card-header">General Settings</div>
      <div class="card-body">
        <form>
          <!-- Church Details -->
          <div class="mb-3">
            <label for="churchName" class="form-label">Church Name</label>
            <input type="text" class="form-control" id="churchName" placeholder="Enter church name">
          </div>
          <div class="mb-3">
            <label for="churchLogo" class="form-label">Church Logo</label>
            <input type="file" class="form-control" id="churchLogo" accept="image/*">
            <div class="mt-3">
              <img id="logoPreview" src="#" alt="Church Logo Preview" style="max-width: 150px; display: none;">
            </div>
          </div>
          <div class="mb-3">
            <label for="churchAddress" class="form-label">Church Address</label>
            <input type="text" class="form-control" id="churchAddress" placeholder="Street, City, State">
          </div>
          <div class="mb-3">
            <label for="contactEmail" class="form-label">Contact Email</label>
            <input type="email" class="form-control" id="contactEmail" placeholder="example@church.com">
          </div>
          <div class="mb-3">
            <label for="contactPhone" class="form-label">Contact Phone</label>
            <input type="text" class="form-control" id="contactPhone" placeholder="+1 234 567 890">
          </div>
        </form>
      </div>
    </div>

    <!-- Module Preferences -->
    <div class="card">
      <div class="card-header">Module Preferences</div>
      <div class="card-body">
        <form>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" id="enableDonations" checked>
            <label class="form-check-label" for="enableDonations">Enable Donations Module</label>
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" id="enableCommunications" checked>
            <label class="form-check-label" for="enableCommunications">Enable Communications</label>
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" id="enableEvents" checked>
            <label class="form-check-label" for="enableEvents">Enable Events Management</label>
          </div>
        </form>
      </div>
    </div>

    <!-- Communications Settings -->
    <div class="card">
      <div class="card-header">Communications Settings</div>
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="emailSignature" class="form-label">Default Email Signature</label>
            <textarea class="form-control" id="emailSignature" rows="3" placeholder="Enter signature for outgoing emails"></textarea>
          </div>
          <div class="mb-3">
            <label for="notificationFrequency" class="form-label">Notification Frequency</label>
            <select class="form-select" id="notificationFrequency">
              <option selected>Instant</option>
              <option>Daily</option>
              <option>Weekly</option>
            </select>
          </div>
        </form>
      </div>
    </div>

    <!-- Donations Settings -->
    <div class="card">
      <div class="card-header">Donations Settings</div>
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="currency" class="form-label">Currency</label>
            <input type="text" class="form-control" id="currency" placeholder="USD, EUR, etc.">
          </div>
          <div class="mb-3">
            <label for="receiptPrefix" class="form-label">Receipt Prefix</label>
            <input type="text" class="form-control" id="receiptPrefix" placeholder="CHURCH-">
          </div>
          <div class="mb-3">
            <label for="donationTypes" class="form-label">Donation Types</label>
            <input type="text" class="form-control" id="donationTypes" placeholder="e.g., Online, Cash, Check">
          </div>
        </form>
      </div>
    </div>

    <!-- Events Settings -->
    <div class="card">
      <div class="card-header">Events Settings</div>
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="defaultEventReminder" class="form-label">Default Event Reminder (hours before)</label>
            <input type="number" class="form-control" id="defaultEventReminder" placeholder="e.g., 24">
          </div>
          <div class="mb-3">
            <label for="checkInMethod" class="form-label">Check-in Method</label>
            <select class="form-select" id="checkInMethod">
              <option selected>Manual</option>
              <option>QR Code</option>
              <option>Mobile App</option>
            </select>
          </div>
        </form>
      </div>
    </div>

    <!-- Membership Settings -->
    <div class="card">
      <div class="card-header">Membership Settings</div>
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="defaultStatus" class="form-label">Default Membership Status</label>
            <select class="form-select" id="defaultStatus">
              <option value="active" selected>Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          <div class="mb-3">
            <label for="joinApproval" class="form-label">Require Join Approval?</label>
            <select class="form-select" id="joinApproval">
              <option selected>No</option>
              <option>Yes</option>
            </select>
          </div>
        </form>
      </div>
    </div>

    <!-- Ministry Settings -->
    <div class="card">
      <div class="card-header">Ministry Settings</div>
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="ministryDescriptions" class="form-label">Ministry Descriptions</label>
            <textarea class="form-control" id="ministryDescriptions" rows="3" placeholder="Provide default details for ministries"></textarea>
          </div>
          <div class="mb-3">
            <label for="volunteerRoleDefault" class="form-label">Default Volunteer Role</label>
            <input type="text" class="form-control" id="volunteerRoleDefault" placeholder="E.g., Helper, Coordinator">
          </div>
        </form>
      </div>
    </div>

    <!-- Save Changes Button -->
    <div class="text-end">
      <button type="submit" class="btn btn-primary">Save Changes</button>
    </div>
  </main>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Get references to the form fields
      const churchNameInput = document.getElementById('churchName');
      const churchAddressInput = document.getElementById('churchAddress');
      const contactEmailInput = document.getElementById('contactEmail');
      const contactPhoneInput = document.getElementById('contactPhone');
      const churchLogoInput = document.getElementById('churchLogo');
      const logoPreview = document.getElementById('logoPreview');
  
      // Get references to the display elements
      const brandName = document.querySelector('.brand');
      const addressDisplay = document.querySelector('.address small');
      const contactDetailsDisplay = document.querySelector('.contact-details small');
  
      // Function to update the display
function updateDisplay() {
  // Update Church Name
  if (churchNameInput.value.trim() !== '') {
    const churchName = churchNameInput.value.trim();

    // Try to get the logo text span by ID (for your markup)
    let logoText = document.getElementById('sidebarLogoText');
    if (logoText) {
      logoText.textContent = churchName.substring(0, 2).toUpperCase();
      logoText.style.display = 'inline-block';
    }

    // Update the full church name (outside the circle)
    // Find the text node after the logo container
    const brandName = document.querySelector('.brand');
    let churchNameText = null;
    for (let node of brandName.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim() !== '') {
        churchNameText = node;
        break;
      }
    }
    if (churchNameText) {
      churchNameText.textContent = ` ${churchName}`;
    }
  }

  // Update Address
  if (churchAddressInput.value.trim() !== '') {
    addressDisplay.textContent = churchAddressInput.value.trim();
  }

  // Update Contact Details
  const email = contactEmailInput.value.trim();
  const phone = contactPhoneInput.value.trim();
  contactDetailsDisplay.textContent = `Email: ${email || 'example@church.com'} | Phone: ${phone || '+1 234 567 890'}`;

  // Update Logo Preview
  if (churchLogoInput.files && churchLogoInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function (e) {
      logoPreview.src = e.target.result;
      logoPreview.style.display = 'block';

      // Replace the text-based logo with the uploaded image
      const logoContainer = document.getElementById('sidebarLogoContainer');
      if (logoContainer) {
        logoContainer.style.backgroundImage = `url(${e.target.result})`;
        logoContainer.style.backgroundSize = 'cover';
        logoContainer.style.backgroundPosition = 'center';
        // Hide the logo text span if present
        let logoText = document.getElementById('sidebarLogoText');
        if (logoText) logoText.style.display = 'none';
      }
    };
    reader.readAsDataURL(churchLogoInput.files[0]);
  } else {
    // Show the text-based logo if no image is uploaded
    let logoText = document.getElementById('sidebarLogoText');
    if (logoText) logoText.style.display = 'inline-block';
    const logoContainer = document.getElementById('sidebarLogoContainer');
    if (logoContainer) {
      logoContainer.style.backgroundImage = '';
    }
  }
}
  
      // Add event listener to the Save Changes button
      document.querySelector('.btn-primary').addEventListener('click', function (e) {
        e.preventDefault(); // Prevent form submission
        updateDisplay();

          // Collect form data
  const formData = new FormData();
  formData.append('churchName', churchNameInput.value.trim());
  formData.append('churchAddress', churchAddressInput.value.trim());
  formData.append('contactEmail', contactEmailInput.value.trim());
  formData.append('contactPhone', contactPhoneInput.value.trim());
  if (churchLogoInput.files[0]) {
    formData.append('churchLogo', churchLogoInput.files[0]);
  }

  // Send data to PHP via AJAX
  fetch('save_settings.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      updateDisplay();
      alert('Settings saved successfully!');
    } else {
      alert('Error saving settings: ' + data.message);
    }
  })
  .catch(error => {
    alert('AJAX error: ' + error);
  });
});
      });

  </script>
  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
